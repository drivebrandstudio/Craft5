-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_fpivudawvsxssnqviqiehdmucvfzltvsyowm` (`primaryOwnerId`),
  CONSTRAINT `fk_fpivudawvsxssnqviqiehdmucvfzltvsyowm` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xrhufgbwejmipvcfgafcikskvsqkojbtdbcq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_odgqxddlacjaqmrssrxayqzdqwfadkmljlmt` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_olhqqguxbrgbrybbgiipbomynlccfkfcwilw` (`dateRead`),
  KEY `fk_shdvirkqynmjlxytmzzodepkevnlflcsglzl` (`pluginId`),
  CONSTRAINT `fk_shdvirkqynmjlxytmzzodepkevnlflcsglzl` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zjrziurhzcgfaecqpwmpyngqtquxrniqemuh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yvynheqixzshnmzzcgfdeejytapsxxrbuyrt` (`sessionId`,`volumeId`),
  KEY `idx_damhlifgmeliosspousniliooiuamcjqrkgz` (`volumeId`),
  CONSTRAINT `fk_iaqclnhbkojbvjqthqqbsvutyiqnzugovxsy` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_snbblfnfimenjarlqmeheckacyietracfjfc` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wgewasediswtwknwrsbcrnbizqumiblitmbt` (`filename`,`folderId`),
  KEY `idx_flmgnpraejpkkymcobjxonpznimhkiyigstq` (`folderId`),
  KEY `idx_nlsvjszmzbdprftalskqgnrgafrlzvhfevys` (`volumeId`),
  KEY `fk_bppfzrrjundpkuefsaqlwsrzpafknfhmztrx` (`uploaderId`),
  CONSTRAINT `fk_bppfzrrjundpkuefsaqlwsrzpafknfhmztrx` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tdaovpynngplaoyapfwcymraygvdcmofyops` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vcfjbetdiiaqwocxwungvfvcknnyttlgqysa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wvrfzwoatodlwnnhllsrwfeofwnbbjyjhmfu` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (4,1,1,1,'Designer-1.jpeg','image',NULL,1024,1024,128010,NULL,0,0,'2024-08-26 17:47:12','2024-08-26 17:47:12','2024-08-26 17:47:12'),(5,1,1,1,'Designer.jpeg','image',NULL,1024,1024,119292,NULL,0,0,'2024-08-26 17:47:12','2024-08-26 17:47:12','2024-08-26 17:47:12'),(6,1,1,1,'sasquatch.png','image',NULL,1024,1024,943270,NULL,0,0,'2024-08-26 17:47:13','2024-08-26 17:47:13','2024-08-26 17:47:13'),(7,1,1,1,'DJI_20240204092448_0006_D-Enhanced-NR.png','image',NULL,350,159,106545,NULL,0,0,'2024-08-26 17:47:13','2024-08-26 17:47:13','2024-08-26 17:47:13'),(8,1,1,1,'201918-01.jpg','image',NULL,6710,4473,5439296,NULL,0,0,'2024-08-26 17:47:14','2024-08-26 17:47:14','2024-08-26 17:47:14'),(9,1,1,1,'Jekyll_08312017_-0379-edit_3D807BF7-96AD-4F46-A0F974BF561ECCDF_cab528c4-b697-44ab-a55a85f0007e8bd9-720x480-2cc51087-5b1f-40c5-ad1e-41fe73d3f70f.jpg','image',NULL,720,480,199442,NULL,0,0,'2024-08-26 17:47:14','2024-08-26 17:47:14','2024-08-26 17:47:14'),(10,1,1,1,'dwp_drivebrand_goldenisles_littlestsimons_SL2_101721__Little-St.-Simons_SL_1727-720x480-a7016ad7-be5b-4900-9985-20293ab94571.jpg','image',NULL,720,480,249115,NULL,0,0,'2024-08-26 17:47:14','2024-08-26 17:47:14','2024-08-26 17:47:14'),(11,1,1,1,'DSC_06482-Edit-2-720x479-4f933cad-23f3-4357-8cb7-3fa1dc47b36a.jpg','image',NULL,720,479,199932,NULL,0,0,'2024-08-26 17:47:14','2024-08-26 17:47:14','2024-08-26 17:47:14'),(12,1,1,1,'Harrington-School_1-720x481-93753ce9-adc5-4be4-a131-a5922e29023e.jpg','image',NULL,720,481,286917,NULL,0,0,'2024-08-26 17:47:14','2024-08-26 17:47:14','2024-08-26 17:47:14'),(13,1,1,1,'DSC_1317_EXPANDED_inn_pool_minified.jpg','image',NULL,2000,1834,434255,NULL,0,0,'2024-08-26 17:47:15','2024-08-26 17:47:15','2024-08-26 17:47:15'),(14,1,1,1,'msp_drivebrand_goldenisles_shrimpboil_060222_-5086-720x480-83cd6ab1-fb5e-48c5-9f0a-fe70b3bed11a.jpg','image',NULL,720,480,179363,NULL,0,0,'2024-08-26 17:47:15','2024-08-26 17:47:15','2024-08-26 17:47:15'),(15,1,1,1,'DSC_3024-720x479-22b2716e-a069-46fa-9062-b4d148c019df.jpg','image',NULL,720,479,230237,NULL,0,0,'2024-08-26 17:47:15','2024-08-26 17:47:15','2024-08-26 17:47:15'),(18,1,1,1,'old_techdiff.png','image',NULL,1919,912,31920,NULL,0,0,'2024-08-26 18:05:53','2024-08-26 18:05:53','2024-08-26 18:05:53'),(19,1,1,1,'DSC_1317_EXPANDED_inn_pool.jpg','image',NULL,2000,1834,2391499,NULL,0,0,'2024-08-26 18:06:35','2024-08-26 18:06:35','2024-08-26 18:06:35'),(20,1,1,1,'DJI_20240204092448_0006_D-Enhanced-NR.png','image',NULL,350,159,106545,NULL,NULL,NULL,'2024-08-26 18:08:26','2024-08-26 18:08:26','2024-08-26 18:08:26'),(22,1,1,1,'Untitled.png','image',NULL,1917,962,1016077,NULL,NULL,NULL,'2024-08-26 18:11:28','2024-08-26 18:11:28','2024-08-26 18:11:28');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_tidcprszdbhnumabooeaiqoheelwgypcndjf` (`siteId`),
  CONSTRAINT `fk_ebtrbadqaegdooqykuodtwodiswlplkifyvq` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tidcprszdbhnumabooeaiqoheelwgypcndjf` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (4,1,NULL),(4,2,NULL),(5,1,NULL),(5,2,NULL),(6,1,NULL),(6,2,NULL),(7,1,NULL),(7,2,NULL),(8,1,NULL),(8,2,NULL),(9,1,NULL),(9,2,NULL),(10,1,NULL),(10,2,NULL),(11,1,NULL),(11,2,NULL),(12,1,NULL),(12,2,NULL),(13,1,NULL),(13,2,NULL),(14,1,NULL),(14,2,NULL),(15,1,NULL),(15,2,NULL),(18,1,NULL),(18,2,NULL),(19,1,NULL),(19,2,NULL),(20,1,NULL),(20,2,NULL),(22,1,NULL),(22,2,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pvjjwtssbcentvbduvfpeqqzgwexnkxqjdav` (`userId`),
  CONSTRAINT `fk_pvjjwtssbcentvbduvfpeqqzgwexnkxqjdav` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_msschlewcwatqgcwitvoiqzjhlhhwhwcqazr` (`groupId`),
  KEY `fk_dldwnqlcuexmzjiaejlyfgbhkrmwypaojbbk` (`parentId`),
  CONSTRAINT `fk_bewvwkixzrhlikmkfnwmysqmegfrvwbsghjb` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dldwnqlcuexmzjiaejlyfgbhkrmwypaojbbk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lqmpmiekbdrldqhobgpildwjpqektxwckkqb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_sjbeloplseexvyxmmzcfqeuckbgxlvpzntba` (`name`),
  KEY `idx_hkydfvutnkwmrfoykaoaeyotrjdlmpudolkq` (`handle`),
  KEY `idx_pgcenpkxtmgdewafkskbfslrvybfefdbdklx` (`structureId`),
  KEY `idx_dbqkksdvuqvtfvhvglbfjaywqkrzrvloowoe` (`fieldLayoutId`),
  KEY `idx_zbaekwisydzbxbbqsajibtooraivmkpkzhmp` (`dateDeleted`),
  CONSTRAINT `fk_czymmiwyxfqrhxduxgjnaovwpxgvrecoaekm` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mofyxkztzpujyjeivgtcgqddtvoqpzkcbiid` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ptwshdicfhsoncviducbjvvsbajyxhprxzbt` (`groupId`,`siteId`),
  KEY `idx_swvcxhehbqesbryvqhqvdmjyvlzxlzjdyjac` (`siteId`),
  CONSTRAINT `fk_ggugfgolomeijkiowjusezbmsuwnskausqpv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qpgjjjowchbtlcwxjwboknxmpvrmmeqitlxl` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_kweumbkqbcpprzpstqvbfzvzgghckehmeqmm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_yrxmusytyxeooawukseshyiapbcczlfymzbb` (`siteId`),
  KEY `fk_wsgfucanxumidxlnnksjwmoplpztpbazztrz` (`userId`),
  CONSTRAINT `fk_alvpdjhesqzoftsgctbgengcavkztkvwkhht` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wsgfucanxumidxlnnksjwmoplpztpbazztrz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_yrxmusytyxeooawukseshyiapbcczlfymzbb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (2,2,'title','2024-08-30 18:28:39',0,1),(28,1,'postDate','2024-08-30 13:29:01',1,1),(28,1,'slug','2024-08-30 13:28:50',1,1),(28,1,'title','2024-08-30 13:28:50',1,1),(28,1,'uri','2024-08-30 13:28:50',1,1),(28,2,'postDate','2024-08-30 13:29:01',0,1),(28,2,'slug','2024-08-30 13:28:50',0,1),(28,2,'title','2024-08-30 13:28:50',0,1),(28,2,'uri','2024-08-30 13:28:50',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_paekqzdkfsyyngfpuyzcorcqidnvqlklmyxe` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_kwisenajtngmbnlmpvswwtthwsckgcbjrzga` (`siteId`),
  KEY `fk_wsvwpyofpttpztqsizyvicvivjweuclxnzui` (`fieldId`),
  KEY `fk_gqbfuujbukhzwemdlakmfykoamuwxnfpmkzu` (`userId`),
  CONSTRAINT `fk_gqbfuujbukhzwemdlakmfykoamuwxnfpmkzu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_iqguwmecfriwseezexyvkcouhptzwmdetyhg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kwisenajtngmbnlmpvswwtthwsckgcbjrzga` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wsvwpyofpttpztqsizyvicvivjweuclxnzui` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'afd9d5f6-4c6c-4c70-8452-acafb6c61ce2','2024-08-30 18:28:39',1,1),(2,2,1,'afd9d5f6-4c6c-4c70-8452-acafb6c61ce2','2024-08-30 18:28:39',0,1),(2,2,8,'ab8b5cc9-692a-4ba3-9007-29f51e4ce344','2024-09-04 18:25:34',0,1),(28,1,2,'b247bec1-e40a-4d2b-a7e9-ae3be987fa0f','2024-08-30 13:29:01',1,1),(28,1,3,'6454f755-a0a7-4507-8fba-9a8abf925407','2024-08-30 13:29:01',1,1),(28,1,4,'d800e333-e30d-40ad-b909-a6207c830501','2024-08-30 13:29:01',1,1),(28,1,5,'9858ea6c-f672-47b7-9f64-c0472715316b','2024-08-30 13:29:01',1,1),(28,2,2,'b247bec1-e40a-4d2b-a7e9-ae3be987fa0f','2024-08-30 13:29:01',0,1),(28,2,3,'6454f755-a0a7-4507-8fba-9a8abf925407','2024-08-30 13:29:01',0,1),(28,2,4,'d800e333-e30d-40ad-b909-a6207c830501','2024-08-30 13:29:01',0,1),(28,2,5,'9858ea6c-f672-47b7-9f64-c0472715316b','2024-08-30 13:29:01',0,1),(28,2,7,'a029caf8-e5d2-46d0-92e6-24e8105b4006','2024-08-30 15:04:37',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ygqyhoyrccxlwglgozevgtebqvenaylpfmpf` (`userId`),
  CONSTRAINT `fk_ygqyhoyrccxlwglgozevgtebqvenaylpfmpf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kewouamsxuoihpcjtpzkpdninrcmylyrcbxp` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_vueircoggunfgaqfqfnrqhaedatcpuabmdzt` (`creatorId`,`provisional`),
  KEY `idx_hydyeakppbedkiawjpuiiidggegauqigstaw` (`saved`),
  KEY `fk_aqqqdwtcnipnupbrzwttjxvonkjyjcwhkeha` (`canonicalId`),
  CONSTRAINT `fk_aqqqdwtcnipnupbrzwttjxvonkjyjcwhkeha` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hnvdywmnyvklhxcvxwsptvyrgceuoijudddp` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_klfowdlidzuoylcncuyxersotbxrlgyecmjz` (`elementId`,`timestamp`,`userId`),
  KEY `fk_fefybvifufbzxjcltexmrpadhnlozfikndii` (`userId`),
  KEY `fk_lntatlylagwiqcxpdzvjkchxtddfzheidwws` (`siteId`),
  KEY `fk_ewltfwkbzztqzvolbzyoxcpyndulsmzavhdl` (`draftId`),
  CONSTRAINT `fk_cmmljpmhssusurhpcxmukospazzmpphwdcmj` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ewltfwkbzztqzvolbzyoxcpyndulsmzavhdl` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fefybvifufbzxjcltexmrpadhnlozfikndii` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lntatlylagwiqcxpdzvjkchxtddfzheidwws` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,2,NULL,'edit','2024-09-04 18:25:34'),(2,1,2,NULL,'save','2024-09-04 18:25:34'),(28,1,2,NULL,'edit','2024-08-30 15:01:51'),(28,1,2,NULL,'save','2024-09-04 19:39:31');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xiepkqprjxabceuefmunxcjmnrdfsvdmxdiy` (`dateDeleted`),
  KEY `idx_cjpvsxwhevvuqidschcpimstbroxbkybmdcx` (`fieldLayoutId`),
  KEY `idx_cckphyvkejwhmjygpigxcsgrlxztlkwdwiir` (`type`),
  KEY `idx_mctzaoeykfdggvrrnhobisjcamfbpcvjrqrj` (`enabled`),
  KEY `idx_fmejkmtdhtgskcubitcjscxtpvurphtvabvd` (`canonicalId`),
  KEY `idx_xuamiibeuwqjjqcdaoyynvdyhsxboeigulbk` (`archived`,`dateCreated`),
  KEY `idx_xpensjwlzgcsjkpeapytqdgxxnogaemytkdg` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_rajrqowwzqkctrjgotreqtyykpvbkuxyocvy` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ozfqkxkjbcfqxnsxegrmvtdcrkskqfvbaivr` (`draftId`),
  KEY `fk_qosqowykcqcohmtxykqpukjgzvhdzdgkxign` (`revisionId`),
  CONSTRAINT `fk_dnhjykilfiaahexhcbgdjjjrfptjmepowdqk` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hktvkiqyuvtqkoycieqhvedopuseefdoblzn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ozfqkxkjbcfqxnsxegrmvtdcrkskqfvbaivr` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qosqowykcqcohmtxykqpukjgzvhdzdgkxign` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-08-22 14:07:09','2024-08-22 14:07:09',NULL,NULL,NULL,'386eb7dc-4954-4dfc-8eb6-76851988c2eb'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-08-26 17:26:34','2024-09-04 18:25:34',NULL,NULL,NULL,'da362b64-fcae-41ec-be41-25f6f6178c0a'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-08-26 17:26:34','2024-08-26 17:26:34',NULL,NULL,NULL,'1aa5bd59-defc-4b3b-bcae-dd6c9a5b73df'),(4,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:12','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'984acd49-644a-49d3-9ed7-60aa6af478e7'),(5,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:12','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'d3994076-3916-4d30-acdd-2e0649ad8341'),(6,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:13','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'145f605a-ef18-4b9d-8ee9-aedbbccc2171'),(7,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:13','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'223bf7e5-dd13-4760-9202-05c3665486f6'),(8,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:13','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'6aadc7fe-26cc-49a8-8a7d-ba4b74251e0a'),(9,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:14','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'c41d78fe-32e9-4036-b216-24df46b2904e'),(10,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:14','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'4b76611e-8967-4da4-9079-89e31afba3b0'),(11,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:14','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'2acc1446-31b5-4a7a-8eba-90ca67b2c71c'),(12,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:14','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'d45a1f96-5072-4004-8bb8-859441085d57'),(13,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:15','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'140965d1-0ce2-40c1-8179-3023beaa69bf'),(14,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:15','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'fa3694fa-ac59-4b36-ab39-acf107dd603b'),(15,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 17:47:15','2024-08-26 18:05:49',NULL,'2024-08-26 18:05:49',NULL,'dd82b049-ecc9-460e-98d0-c8988b77b41b'),(17,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-08-26 17:47:23','2024-08-26 17:47:23',NULL,NULL,NULL,'e59a502b-f87e-4ae2-9eee-9fab7ba68131'),(18,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 18:05:52','2024-08-26 18:05:59',NULL,'2024-08-26 18:05:59',NULL,'e5b43491-feb4-44f8-b001-41d77d14fe3e'),(19,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 18:06:35','2024-08-26 18:07:03',NULL,'2024-08-26 18:07:03',NULL,'d93a0ca6-2019-4d75-bd8f-217297220a62'),(20,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 18:08:26','2024-08-26 18:08:26',NULL,NULL,NULL,'9aa74986-0983-493e-bd11-9c846b0c47a0'),(21,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-08-26 18:11:21','2024-08-26 18:11:21',NULL,NULL,NULL,'50c1f79f-5401-49d4-abd9-64a2d8188238'),(22,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-08-26 18:11:27','2024-08-26 18:11:27',NULL,NULL,NULL,'356a50ae-10bf-4006-96af-aea7227e923d'),(24,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2024-08-26 18:11:34','2024-08-26 18:11:34',NULL,NULL,NULL,'6818d74c-44c7-4d91-96f0-f578ce7b884e'),(25,2,NULL,5,1,'craft\\elements\\Entry',1,0,'2024-08-26 18:12:06','2024-08-26 18:12:06',NULL,NULL,NULL,'1c065d54-aaba-4a6f-b4dc-d303103b92f4'),(27,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2024-08-26 18:15:03','2024-08-26 18:15:03',NULL,NULL,NULL,'d64cb5a4-d112-4886-97d2-4e688f9a0a54'),(28,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-08-30 13:28:42','2024-09-04 19:39:31',NULL,NULL,NULL,'eedb9bec-bd5e-4a7a-a5a7-c8e0db43ea73'),(29,28,NULL,7,3,'craft\\elements\\Entry',1,0,'2024-08-30 13:29:01','2024-08-30 13:29:01',NULL,NULL,NULL,'86530911-babb-4337-93c3-b7379beefcef'),(33,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-08-30 13:44:07','2024-08-30 15:04:36',NULL,NULL,NULL,'7d36908b-ec39-410a-8f48-b3211c1635db'),(34,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-30 13:44:07','2024-08-30 15:04:36',NULL,NULL,NULL,'81ad6691-8037-45fd-88ca-1e9a44073e24'),(35,28,NULL,8,3,'craft\\elements\\Entry',1,0,'2024-08-30 13:44:07','2024-08-30 13:44:07',NULL,NULL,NULL,'120ef40e-464a-4274-b464-c0a9827106ee'),(36,33,NULL,9,4,'craft\\elements\\Entry',1,0,'2024-08-30 13:44:07','2024-08-30 13:44:07',NULL,NULL,NULL,'d3006302-d602-40ce-bcbf-cc031dac45c5'),(37,34,NULL,10,5,'craft\\elements\\Entry',1,0,'2024-08-30 13:44:07','2024-08-30 13:44:07',NULL,NULL,NULL,'cda04c6e-7474-49f8-a60a-412ade91312b'),(41,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:37','2024-08-30 15:04:37',NULL,NULL,NULL,'04613370-1d5a-40b1-9c61-035c18a55c62'),(42,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:37','2024-08-30 15:04:37',NULL,NULL,NULL,'3102d763-939f-4477-a1fd-6cb60dcb8613'),(43,28,NULL,11,3,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:37','2024-08-30 15:04:37',NULL,NULL,NULL,'ea59f12c-bc01-48e2-88cf-fc8687a971a5'),(44,33,NULL,12,4,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:36','2024-08-30 15:04:37',NULL,NULL,NULL,'a955930b-8fb3-4062-abc4-092b7e530e89'),(45,34,NULL,13,5,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:36','2024-08-30 15:04:37',NULL,NULL,NULL,'1b93c139-f583-464b-b542-c41ba351b9b6'),(46,41,NULL,14,4,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:37','2024-08-30 15:04:37',NULL,NULL,NULL,'49c82d06-d5f4-4c59-a202-46e509840077'),(47,42,NULL,15,5,'craft\\elements\\Entry',1,0,'2024-08-30 15:04:37','2024-08-30 15:04:37',NULL,NULL,NULL,'b8900b64-2d14-44dc-aa30-bcd14ae8d106'),(48,2,NULL,16,1,'craft\\elements\\Entry',1,0,'2024-08-30 18:28:06','2024-08-30 18:28:06',NULL,NULL,NULL,'f68885d9-46ee-4eb9-b95c-0a9b03a856e2'),(49,2,NULL,17,1,'craft\\elements\\Entry',1,0,'2024-08-30 18:28:39','2024-08-30 18:28:39',NULL,NULL,NULL,'123ab769-2fd3-4eca-b9ce-b568e29d6b3c'),(50,2,NULL,18,1,'craft\\elements\\Entry',1,0,'2024-09-03 20:35:08','2024-09-03 20:35:08',NULL,NULL,NULL,'2c223442-f633-4555-bd8f-a034bb58aca8'),(52,2,NULL,19,1,'craft\\elements\\Entry',1,0,'2024-09-04 18:24:55','2024-09-04 18:24:55',NULL,NULL,NULL,'b56f2a6a-a102-48d4-a977-8f4ed4c03a9e'),(54,2,NULL,20,1,'craft\\elements\\Entry',1,0,'2024-09-04 18:25:34','2024-09-04 18:25:34',NULL,NULL,NULL,'cf8599fc-ddaf-437e-a0ce-7d157be73e4e'),(55,28,NULL,21,3,'craft\\elements\\Entry',1,0,'2024-09-04 19:39:31','2024-09-04 19:39:31',NULL,NULL,NULL,'b9440616-f3ef-46f0-86f5-e9829fe2a716');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_uwwujkpgwgnovtlwrvwwqnqunnkoqctcczba` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_kuejsqwozruuybwcyoshmgnydlkgddjknymu` (`ownerId`),
  CONSTRAINT `fk_cthhrntampjqamcvubhniptjcwruymwnpvak` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kuejsqwozruuybwcyoshmgnydlkgddjknymu` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
INSERT INTO `elements_owners` VALUES (33,28,1),(34,28,2),(36,35,1),(37,35,2),(41,28,3),(42,28,4),(44,43,1),(44,55,1),(45,43,2),(45,55,2),(46,43,3),(46,55,3),(47,43,4),(47,55,4);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qeqcvmqalvxihmwyuswdkjbtzmythwwojlzi` (`elementId`,`siteId`),
  KEY `idx_wamiuqaobrneyudlrrovvngpxikarhaldguf` (`siteId`),
  KEY `idx_hhhtjhoxkoooxofzbnhfxqgyshycbujxzhlq` (`title`,`siteId`),
  KEY `idx_aawszytietbotmbmvhvivmokufjikngdsfcg` (`slug`,`siteId`),
  KEY `idx_bslxudojfdksmptwzxiawdpukjwulbmkddhl` (`enabled`),
  KEY `idx_wjaufxblhrofuareeajnihwocbqvblyhwgpm` (`uri`,`siteId`),
  CONSTRAINT `fk_cezfgosixqmglwmhydbzjsbebryjbwlwuhpb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_riupbxlijuwynnncxpiyzclpajviqvmjdlap` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,2,NULL,NULL,NULL,NULL,1,'2024-08-22 14:07:09','2024-08-22 14:07:09','50065bb1-88f1-4b37-a90b-49d00b7d0b7f'),(2,2,2,'Hometestettest','home','__home__','{\"ab8b5cc9-692a-4ba3-9007-29f51e4ce344\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Home but for twittah\", \"handle\": null, \"imageId\": \"20\", \"description\": \"Twitter stuff ya know?\"}, \"facebook\": {\"title\": \"faceboook hooome\", \"handle\": null, \"imageId\": \"22\", \"description\": \"describe this for fb? nah ill pass\"}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": {\"1\": \"Home but diff form title\"}, \"descriptionRaw\": \"Description for the site sure why not\"}, \"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-26 17:26:34','2024-09-04 18:25:34','32eb9c2e-6f2e-40d6-b163-f1e020a4517a'),(4,3,2,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 17:26:34','2024-08-26 17:26:34','15c14b46-3e09-4a5e-b970-3bd7208b3765'),(5,3,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 17:26:34','2024-08-26 17:26:34','0ecc5b03-d272-457b-ad1e-e8ee746e6b13'),(6,4,2,'Designer 1',NULL,NULL,NULL,1,'2024-08-26 17:47:12','2024-08-26 17:47:12','90e8da08-05c8-4b1d-829b-63a0cb606451'),(7,4,1,'Designer 1',NULL,NULL,NULL,1,'2024-08-26 17:47:12','2024-08-26 17:47:12','55217ea1-94d3-4989-9b79-e347c736edc0'),(8,5,2,'Designer',NULL,NULL,NULL,1,'2024-08-26 17:47:12','2024-08-26 17:47:12','e72baed5-618d-48e7-8808-8b3d6358dd23'),(9,5,1,'Designer',NULL,NULL,NULL,1,'2024-08-26 17:47:12','2024-08-26 17:47:12','b1138658-c0fc-4823-a65b-a7f2adcacef3'),(10,6,2,'Sasquatch',NULL,NULL,NULL,1,'2024-08-26 17:47:13','2024-08-26 17:47:13','5216751c-19d8-4c5e-b2de-496bd3ebaa3e'),(11,6,1,'Sasquatch',NULL,NULL,NULL,1,'2024-08-26 17:47:13','2024-08-26 17:47:13','fa8328d3-666e-44e7-922c-d03b63cc9c7b'),(12,7,2,'DJI 20240204092448 0006 D Enhanced NR',NULL,NULL,NULL,1,'2024-08-26 17:47:13','2024-08-26 17:47:13','44542d40-7717-4875-9267-8a48ba61217d'),(13,7,1,'DJI 20240204092448 0006 D Enhanced NR',NULL,NULL,NULL,1,'2024-08-26 17:47:13','2024-08-26 17:47:13','ae65b637-4e9e-45b4-b648-77c18506209a'),(14,8,2,'201918 01',NULL,NULL,NULL,1,'2024-08-26 17:47:13','2024-08-26 17:47:13','c947a194-82b1-4cf9-95fc-e7a094c7bcc0'),(15,8,1,'201918 01',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','4e06b7f8-584b-4631-9836-35b9bb0b9ba3'),(16,9,2,'Jekyll 08312017 0379 edit 3 D807 BF7 96 AD 4 F46 A0 F974 BF561 ECCDF cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','329832e6-2b68-4f8e-8486-a083e0b5fa5a'),(17,9,1,'Jekyll 08312017 0379 edit 3 D807 BF7 96 AD 4 F46 A0 F974 BF561 ECCDF cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','c2a0bbd6-5ce5-420c-afd3-48b8ddf50246'),(18,10,2,'Dwp drivebrand goldenisles littlestsimons SL2 101721 Little St Simons SL 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','2ac1d591-9518-42a1-ac0c-5777a1cad9e3'),(19,10,1,'Dwp drivebrand goldenisles littlestsimons SL2 101721 Little St Simons SL 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','c6c24996-cb8d-40c3-8b95-3f90c79e636a'),(20,11,2,'DSC 06482 Edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','9d1a779e-6483-44be-a50a-ce20926e7337'),(21,11,1,'DSC 06482 Edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','d72e11d9-7006-4cc2-ba18-d9d16483ec2e'),(22,12,2,'Harrington School 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','e6a2b5c6-5e0e-44ec-93f7-c0b2d7a29d53'),(23,12,1,'Harrington School 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e',NULL,NULL,NULL,1,'2024-08-26 17:47:14','2024-08-26 17:47:14','82699ae1-eb5d-4144-abce-3ccf1ee7e04a'),(24,13,2,'DSC 1317 EXPANDED inn pool minified',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','e2ba9099-c921-495b-a8bc-1cd1982e628d'),(25,13,1,'DSC 1317 EXPANDED inn pool minified',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','c3c057a6-bde9-45c2-9447-a4561fd341a6'),(26,14,2,'Msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','79ad5845-9268-4a40-89f0-58b708c8d4d6'),(27,14,1,'Msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','56aa8d06-6b58-4adc-a157-5b969d1c8dd7'),(28,15,2,'DSC 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','98653454-7203-45c2-80d4-9b75121e6f99'),(29,15,1,'DSC 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df',NULL,NULL,NULL,1,'2024-08-26 17:47:15','2024-08-26 17:47:15','1d8cdbd3-5f2e-4c6d-8a22-ebcd4806e2e9'),(32,17,2,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4]}',1,'2024-08-26 17:47:23','2024-08-26 17:47:23','0ff7f0ff-07dd-43cd-954e-730f567f46d9'),(33,17,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4]}',1,'2024-08-26 17:47:23','2024-08-26 17:47:23','249ddac9-9ae4-49b0-9d07-8e60ab956c94'),(34,18,2,'Old techdiff',NULL,NULL,NULL,1,'2024-08-26 18:05:52','2024-08-26 18:05:52','0bf4526c-b634-46f2-9f99-3135c3be83cf'),(35,18,1,'Old techdiff',NULL,NULL,NULL,1,'2024-08-26 18:05:53','2024-08-26 18:05:53','e9472976-3ea7-4488-99f0-20c8d5e3042d'),(36,19,2,'DSC 1317 EXPANDED inn pool',NULL,NULL,NULL,1,'2024-08-26 18:06:35','2024-08-26 18:06:35','2fc9065a-18fe-4dab-9fc7-38d474274a0a'),(37,19,1,'DSC 1317 EXPANDED inn pool',NULL,NULL,NULL,1,'2024-08-26 18:06:35','2024-08-26 18:06:35','5a752793-2d66-4eab-8578-89780dda7fb5'),(38,20,2,'DJI 20240204092448 0006 D Enhanced NR',NULL,NULL,NULL,1,'2024-08-26 18:08:26','2024-08-26 18:08:26','32a2405a-4340-46ba-9e31-1f565018de22'),(39,20,1,'DJI 20240204092448 0006 D Enhanced NR',NULL,NULL,NULL,1,'2024-08-26 18:08:26','2024-08-26 18:08:26','7a162357-8b31-4d59-bde4-f69d6509986b'),(40,21,2,'Hometestet','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:11:21','2024-08-26 18:11:21','42f2dbc2-01fa-46d5-a062-dcb7d5f3e11d'),(41,21,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:11:21','2024-08-26 18:11:21','f3e3cc18-395a-45e3-a95c-f2a2dea6a37e'),(42,22,2,'Untitled',NULL,NULL,NULL,1,'2024-08-26 18:11:27','2024-08-26 18:11:27','058daa21-66ba-4139-8ac4-6a44d3b70e54'),(43,22,1,'Untitled',NULL,NULL,NULL,1,'2024-08-26 18:11:28','2024-08-26 18:11:28','dfb1dd45-9542-45f7-bc05-4254e0f9c243'),(46,24,2,'Hometestet','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:11:34','2024-08-26 18:11:34','6cf91a3c-2965-40bb-84b6-1d027b5b207e'),(47,24,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:11:34','2024-08-26 18:11:34','2814c3ed-98bc-4536-b0fd-8e94ae787b99'),(48,25,2,'Hometestet','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:12:06','2024-08-26 18:12:06','ea87b1fc-a3ea-4c95-b877-b9010ff78d60'),(49,25,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": []}',1,'2024-08-26 18:12:06','2024-08-26 18:12:06','3c66da11-37c2-4960-9857-e991277444d0'),(52,27,2,'Hometestet','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-26 18:15:03','2024-08-26 18:15:03','d4b5b723-c95d-482b-bc1f-dd7e3c1eeef5'),(53,27,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-26 18:15:03','2024-08-26 18:15:03','f8d7ea80-b953-4979-8837-00733a1a477c'),(54,28,2,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"be32a40f-0223-4e72-b127-daba7fef164c\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}, \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 13:28:42','2024-09-04 19:39:31','301e731e-ffea-42dd-b1ed-b760d53074ee'),(56,29,2,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"9858ea6c-f672-47b7-9f64-c0472715316b\": \"I swear this was important\", \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 13:29:01','2024-08-30 13:29:01','099923cc-38de-461d-98bf-f51a1af1b64a'),(57,29,1,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"9858ea6c-f672-47b7-9f64-c0472715316b\": \"I swear this was important\", \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 13:29:01','2024-08-30 13:29:01','12c7934a-486c-487f-8a9a-8c9bf480681a'),(64,33,2,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','7e7586a2-c5db-43a6-b404-87e5bab15de3'),(65,33,1,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','569b3f00-99db-4734-b813-deaf0b725f1f'),(66,34,2,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','13ad1765-bf04-4906-a8c6-4cd10dd409bb'),(67,34,1,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','7711aada-cc43-4626-8f21-8eec59b9c1d9'),(68,35,2,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','5c8e80d1-4694-4558-a6cb-cb25da227018'),(69,35,1,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','fdc1ec75-879a-46cc-ae44-7ed054ff86ba'),(70,36,2,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','bed56f5b-7489-49c1-8839-f7a68c57e5e7'),(71,36,1,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','6d3a7ad0-96f5-47af-bc25-1ee31ed1a5b2'),(72,37,2,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','7bfa677a-4591-4037-9414-a850893b26d1'),(73,37,1,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 13:44:07','2024-08-30 13:44:07','8adea88b-f37f-449c-ade4-d22bc6a11a11'),(80,41,2,NULL,'__temp_dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Another section\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','7bf4c506-71db-4b98-a9cb-2b9c2ccc98d6'),(81,41,1,NULL,'__temp_dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Another section\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','79cb5fef-2bce-4f21-9b2f-fdd3f247b9b9'),(82,42,2,NULL,'__temp_kvifbcaoumnmobggnxpqvgojuvnpgctojjje',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>wow this will be a long paragraph.</p><p> </p><p>We have a wysiwyg editor here so its pretty cool.</p><p> </p><p>ye know</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','0fb6232c-da40-4ed1-8780-0e71c5bebde2'),(83,42,1,NULL,'__temp_kvifbcaoumnmobggnxpqvgojuvnpgctojjje',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>wow this will be a long paragraph.</p><p> </p><p>We have a wysiwyg editor here so its pretty cool.</p><p> </p><p>ye know</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','66bd283d-b0bf-4fbe-bee7-596f1bcd95b0'),(84,43,2,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','fcd748fe-e215-45b2-92c5-a6098ae7b66d'),(85,43,1,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','39088aa5-b08c-4495-acdb-f97b5490be4b'),(86,44,2,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','33ddeb80-eded-41b3-9775-0ecb1460e32f'),(87,44,1,NULL,'__temp_iorifhitpkghvtnygzfwyixlfmsoxlcosxph',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Part of post 1\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','e8332b00-da71-4f46-8e01-61fc3dfa7051'),(88,45,2,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','c4b0e676-ae8c-49d5-a06e-91d9d7c2b80a'),(89,45,1,NULL,'test',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>Things are important in thnis one</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','20168c0d-2bc8-4851-a403-22323c86928b'),(90,46,2,NULL,'__temp_dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Another section\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','496a79c8-6fca-4338-8760-714508f7f42f'),(91,46,1,NULL,'__temp_dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk',NULL,'{\"94061721-49f3-43f3-aeb9-ef102fd27f43\": \"Another section\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','162687fc-d7e8-41f9-a9d9-9c3c6b8d3825'),(92,47,2,NULL,'__temp_kvifbcaoumnmobggnxpqvgojuvnpgctojjje',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>wow this will be a long paragraph.</p><p> </p><p>We have a wysiwyg editor here so its pretty cool.</p><p> </p><p>ye know</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','c73e1468-d792-4436-8243-a1365f9ddcfa'),(93,47,1,NULL,'__temp_kvifbcaoumnmobggnxpqvgojuvnpgctojjje',NULL,'{\"2d847eee-7826-49b9-9156-514fcd6290db\": \"<p>wow this will be a long paragraph.</p><p> </p><p>We have a wysiwyg editor here so its pretty cool.</p><p> </p><p>ye know</p>\"}',1,'2024-08-30 15:04:37','2024-08-30 15:04:37','48f6c19a-104e-4fca-83e6-5244084c24a7'),(94,48,2,'Hometestet','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-30 18:28:06','2024-08-30 18:28:06','6fc9a597-48d3-465c-8296-ca34119b118e'),(95,48,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-30 18:28:06','2024-08-30 18:28:06','0736bc81-a21f-4f0a-8909-00f8e45cdc08'),(96,49,2,'Hometestettest','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-30 18:28:39','2024-08-30 18:28:39','11362003-e5ba-4f4a-8d2d-432bd4b61bfa'),(97,49,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-08-30 18:28:39','2024-08-30 18:28:39','9dee0ff8-fe19-4a70-87fe-c133eacabc67'),(98,50,1,'Home','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-09-03 20:35:08','2024-09-03 20:35:08','ca4273fa-b632-43b2-8ffd-7634656fa165'),(99,50,2,'Hometestettest','home','__home__','{\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-09-03 20:35:08','2024-09-03 20:35:08','f03d1dba-67f9-477c-ac8c-8ad07d42fa2c'),(101,52,2,'Hometestettest','home','__home__','{\"ab8b5cc9-692a-4ba3-9007-29f51e4ce344\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Home but diff form title - Craft 5caffold\", \"handle\": null, \"imageId\": \"\", \"description\": \"Description for the site sure why not\"}, \"facebook\": {\"title\": \"Home but diff form title - Craft 5caffold\", \"handle\": null, \"imageId\": \"\", \"description\": \"Description for the site sure why not\"}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": {\"1\": \"Home but diff form title\"}, \"descriptionRaw\": \"Description for the site sure why not\"}, \"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-09-04 18:24:55','2024-09-04 18:24:55','467e1d00-b19a-4a2d-9e03-66a92c8256f3'),(103,54,2,'Hometestettest','home','__home__','{\"ab8b5cc9-692a-4ba3-9007-29f51e4ce344\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Home but for twittah\", \"handle\": null, \"imageId\": \"20\", \"description\": \"Twitter stuff ya know?\"}, \"facebook\": {\"title\": \"faceboook hooome\", \"handle\": null, \"imageId\": \"22\", \"description\": \"describe this for fb? nah ill pass\"}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": {\"1\": \"Home but diff form title\"}, \"descriptionRaw\": \"Description for the site sure why not\"}, \"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\": [22, 20]}',1,'2024-09-04 18:25:34','2024-09-04 18:25:34','906b15ca-3c08-4be8-b902-4ca452baee4e'),(104,55,2,'first article','first-article','blog/first-article','{\"6454f755-a0a7-4507-8fba-9a8abf925407\": {\"date\": \"2024-08-31 07:00:00\"}, \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\": \"Something important\", \"be32a40f-0223-4e72-b127-daba7fef164c\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}, \"d800e333-e30d-40ad-b909-a6207c830501\": [22]}',1,'2024-09-04 19:39:31','2024-09-04 19:39:31','a7ad1af1-cd80-49af-b66f-22dd510b1cec');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ohrwxqxmblqlaecoitvkzphejpdnidlljiiw` (`postDate`),
  KEY `idx_jmbroftpdvacjmfgmpomogcqmirvjsthyaor` (`expiryDate`),
  KEY `idx_zqtgowrmptptyiveudamltkfncuucdfculls` (`sectionId`),
  KEY `idx_jvsgzuryicgzqcskdnkrgkkxdinahicvskao` (`typeId`),
  KEY `idx_ytabbvituzyewnljxufipyfzqitqpkxcdsub` (`primaryOwnerId`),
  KEY `idx_jwqicarophnfxigmwepuurgyupqdadfmffsw` (`fieldId`),
  KEY `fk_dqhqlnbzaphamvfmijiyuzvkcmqswuigftrg` (`parentId`),
  CONSTRAINT `fk_dqhqlnbzaphamvfmijiyuzvkcmqswuigftrg` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fdnbbooerfvgwozvfaemamupmqyqetosmxjk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rwstrodwsaxfawylrzedujfpsajfyodqfhgs` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sxpbkhkoefrbdgsxzjmbyzcxjadwrdhisies` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_willkdyvaayjwaycosslsfuzogbkqhjslfrf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zijftsucwwrreqrvxiytkjsqxxkepglcuwiy` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 17:26:34','2024-08-26 17:26:34'),(3,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 17:26:34','2024-08-26 17:26:34'),(17,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 17:47:23','2024-08-26 17:47:23'),(21,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 18:11:21','2024-08-26 18:11:21'),(24,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 18:11:34','2024-08-26 18:11:34'),(25,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 18:12:06','2024-08-26 18:12:06'),(27,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-26 18:15:03','2024-08-26 18:15:03'),(28,2,NULL,NULL,NULL,2,'2024-08-30 13:29:00',NULL,NULL,'2024-08-30 13:28:42','2024-08-30 13:29:01'),(29,2,NULL,NULL,NULL,2,'2024-08-30 13:29:00',NULL,NULL,'2024-08-30 13:29:01','2024-08-30 13:29:01'),(33,NULL,NULL,28,7,3,'2024-08-30 13:42:00',NULL,NULL,'2024-08-30 13:44:07','2024-08-30 13:44:07'),(34,NULL,NULL,28,7,4,'2024-08-30 13:43:00',NULL,NULL,'2024-08-30 13:44:07','2024-08-30 13:44:07'),(35,2,NULL,NULL,NULL,2,'2024-08-30 13:29:00',NULL,NULL,'2024-08-30 13:44:07','2024-08-30 13:44:07'),(36,NULL,NULL,35,7,3,'2024-08-30 13:42:00',NULL,NULL,'2024-08-30 13:44:07','2024-08-30 13:44:07'),(37,NULL,NULL,35,7,4,'2024-08-30 13:43:00',NULL,NULL,'2024-08-30 13:44:07','2024-08-30 13:44:07'),(41,NULL,NULL,28,7,3,'2024-08-30 15:01:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(42,NULL,NULL,28,7,4,'2024-08-30 15:02:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(43,2,NULL,NULL,NULL,2,'2024-08-30 13:29:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(44,NULL,NULL,43,7,3,'2024-08-30 13:42:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(45,NULL,NULL,43,7,4,'2024-08-30 13:43:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(46,NULL,NULL,43,7,3,'2024-08-30 15:01:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(47,NULL,NULL,43,7,4,'2024-08-30 15:02:00',NULL,NULL,'2024-08-30 15:04:37','2024-08-30 15:04:37'),(48,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-30 18:28:06','2024-08-30 18:28:06'),(49,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-08-30 18:28:39','2024-08-30 18:28:39'),(50,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-09-03 20:35:08','2024-09-03 20:35:08'),(52,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-09-04 18:24:55','2024-09-04 18:24:55'),(54,1,NULL,NULL,NULL,1,'2024-08-26 17:26:00',NULL,NULL,'2024-09-04 18:25:34','2024-09-04 18:25:34'),(55,2,NULL,NULL,NULL,2,'2024-08-30 13:29:00',NULL,NULL,'2024-09-04 19:39:31','2024-09-04 19:39:31');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_huvavozfwitoqmncibmgondakizwhkkrkllg` (`authorId`),
  KEY `idx_trlbupinbqhmvfqaewilkktkvupfnnjqnloj` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_ebhqezxxkouzqzhsplergrtygwhsoxrcwofz` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jcnnsmiezgepwowmjrdyqbiuaccaukvdguef` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
INSERT INTO `entries_authors` VALUES (28,1,1),(29,1,1),(35,1,1),(43,1,1),(55,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uqcoszwnoprftlyddjayehhghiupvqyvxedj` (`fieldLayoutId`),
  KEY `idx_fpkyidoxvnadjqripoegzqcfpoyzrvjuqjdn` (`dateDeleted`),
  CONSTRAINT `fk_jayhrgoqjwqddvjssthlczndkevuyqwkpwtv` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'Home','home','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-08-26 17:26:32','2024-09-03 20:43:43',NULL,'3eed0c77-3b75-46cd-8e31-351f3c83f416'),(2,3,'Blog','blog','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-08-30 13:27:04','2024-09-04 19:39:22',NULL,'48c74af2-dc9f-4a19-8a9a-5e72de6b2950'),(3,4,'Subhead','subhead','',NULL,0,'site','','',1,'site','',1,'2024-08-30 13:40:27','2024-08-30 13:40:27',NULL,'7c0dae6e-f903-4671-869a-4b207ce5f4f4'),(4,5,'Text','text','',NULL,0,'site','','',1,'site','',1,'2024-08-30 13:41:20','2024-08-30 13:44:00',NULL,'b9f9ee47-0657-457a-b3e2-adf8f45280fc');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gyocgjhawgymhtryqtxvvvprqsaasqgphqfp` (`dateDeleted`),
  KEY `idx_vsxqjswlzwkrsnynxnelltmdhusostzhrkkg` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"337f01ac-5651-4ae5-a735-83c9eb5e6bd5\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"05d73b00-2045-4941-805b-de103eac0fae\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-08-26T17:25:02+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"4f44f246-357b-4552-a587-38f11cd9d378\", \"required\": false, \"dateAdded\": \"2024-08-26T17:26:32+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ab8b5cc9-692a-4ba3-9007-29f51e4ce344\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"cca50fd5-eae7-46d1-a534-225f1a1dd71d\", \"required\": false, \"dateAdded\": \"2024-09-03T20:43:43+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-08-26 17:26:32','2024-09-03 20:43:43',NULL,'4d2a3761-91d0-4db9-bd01-15d069258eb8'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"c0903bb8-20dd-4582-b422-be90843b70bf\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"7b0fa929-d748-4dd1-8b17-8e3ddcd3ed56\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-08-26T17:28:44+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-08-26 17:29:56','2024-08-26 17:29:56',NULL,'223262e3-ab4c-4fc3-8ccf-a53023bae4a0'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"00d132d0-ba49-497d-a6b1-961e3543a389\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"741c3acb-9eba-4299-b353-4d89288cc6c9\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-08-30T13:23:17+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"be32a40f-0223-4e72-b127-daba7fef164c\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"cca50fd5-eae7-46d1-a534-225f1a1dd71d\", \"required\": false, \"dateAdded\": \"2024-09-04T19:39:22+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2dc0eec0-8212-489c-92c3-5ef43da4bf6f\", \"required\": false, \"dateAdded\": \"2024-08-30T13:27:04+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"6454f755-a0a7-4507-8fba-9a8abf925407\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"177c74bc-bb8e-490b-b0f8-3cc4515e7af0\", \"required\": false, \"dateAdded\": \"2024-08-30T13:27:04+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"d800e333-e30d-40ad-b909-a6207c830501\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2aadf49b-1991-42e6-b44a-67b81ca12c34\", \"required\": false, \"dateAdded\": \"2024-08-30T13:27:04+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"a029caf8-e5d2-46d0-92e6-24e8105b4006\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"b933d220-df03-410e-a4cc-dc86a74d19c9\", \"required\": false, \"dateAdded\": \"2024-08-30T13:42:40+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-08-30 13:27:04','2024-09-04 19:39:22',NULL,'bf9ebec4-a500-4811-8e57-7a76e355da50'),(4,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"9cb0214a-dee7-4c1e-b3f8-29519dbc416f\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"1d1066c5-a235-4b95-b769-ca31d14ff483\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-08-30T13:38:32+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"94061721-49f3-43f3-aeb9-ef102fd27f43\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"2dc0eec0-8212-489c-92c3-5ef43da4bf6f\", \"required\": false, \"dateAdded\": \"2024-08-30T13:40:27+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-08-30 13:40:27','2024-08-30 13:40:27',NULL,'f6df1b18-a5d7-4bb6-b3f1-df14de36df46'),(5,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"85a51592-60ea-4318-bbd5-3be118b97280\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"c17c88fd-366f-4921-afbe-bf2cbbf15a36\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-08-30T13:39:35+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"2d847eee-7826-49b9-9156-514fcd6290db\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"871e17fd-93c5-4f99-b004-ebbd5303689b\", \"required\": false, \"dateAdded\": \"2024-08-30T13:41:20+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-08-30 13:41:20','2024-08-30 13:41:20',NULL,'1f6ab771-bb64-4864-a666-2074c232c5a4');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jqpxkaeomegcdossjpqtgiliydryuticjamb` (`handle`,`context`),
  KEY `idx_rwyymchvqvclkophawfytcgdcgadprbocqqq` (`context`),
  KEY `idx_hfxvhuisiatyawgfebepnguebeuodlwjtqdv` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Images','images','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":15,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-08-26 17:26:29','2024-08-26 17:46:29',NULL,'4f44f246-357b-4552-a587-38f11cd9d378'),(2,'Summary','summary','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-30 13:25:25','2024-08-30 13:25:25',NULL,'2dc0eec0-8212-489c-92c3-5ef43da4bf6f'),(3,'Date','date','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Date','{\"max\":null,\"min\":null,\"minuteIncrement\":30,\"showDate\":true,\"showTime\":false,\"showTimeZone\":false}','2024-08-30 13:25:37','2024-08-30 13:25:37',NULL,'177c74bc-bb8e-490b-b0f8-3cc4515e7af0'),(4,'Thumbnail','thumbnail','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-08-30 13:25:59','2024-08-30 13:25:59',NULL,'2aadf49b-1991-42e6-b44a-67b81ca12c34'),(5,'Article','article','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-08-30 13:27:00','2024-08-30 13:27:00',NULL,'ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6'),(6,'Article Text','articleText','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"*\",\"ckeConfig\":null,\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-08-30 13:41:11','2024-08-30 13:41:11',NULL,'871e17fd-93c5-4f99-b004-ebbd5303689b'),(7,'Article Content','articleContent','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":null,\"entryTypes\":[\"7c0dae6e-f903-4671-869a-4b207ce5f4f4\",\"b9f9ee47-0657-457a-b3e2-adf8f45280fc\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2024-08-30 13:41:25','2024-09-03 20:35:08',NULL,'b933d220-df03-410e-a4cc-dc86a74d19c9'),(8,'SEO','seo','global',NULL,NULL,0,'none',NULL,'ether\\seo\\fields\\SeoField','{\"description\":\"\",\"hideSocial\":\"\",\"robots\":[\"\",\"\",\"\",\"\",\"\",\"\"],\"socialImage\":\"\",\"suffixAsPrefix\":null,\"title\":[{\"key\":\"1\",\"locked\":\"0\",\"template\":\"{title}\"},{\"key\":\"2\",\"locked\":\"1\",\"template\":\" - {{ siteName }}\"}],\"titleSuffix\":null}','2024-09-03 20:43:31','2024-09-03 20:43:31',NULL,'cca50fd5-eae7-46d1-a534-225f1a1dd71d');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bckmpvyjepvbnnvgrjtgxqyylpgkfbrzzzvb` (`name`),
  KEY `idx_bgfrkekzcimnoyrgzpgseelkomuzjfemkkgg` (`handle`),
  KEY `idx_bkmpuzaikplxgsshlqqbwaejncljfebhtxnc` (`fieldLayoutId`),
  KEY `idx_uehgxjpfghoppcmjukltxkllhaatvgypjksh` (`sortOrder`),
  CONSTRAINT `fk_drgcaanlpcxqsihmnuojexfyifxnusazrtst` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ldsbkgwayxwxffzuxcmmhphshzwrptkfzudu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[\"sites.2eb36cc0-a60a-4071-a815-ce808da649b2:read\", \"sites.ca348b20-8894-41e8-8cbd-4b61bda22ba5:read\", \"elements.drafts:read\", \"elements.revisions:read\", \"elements.inactive:read\", \"sections.663ae8bc-bf43-4af2-9213-eb15474f28c0:read\", \"sections.5583777d-063b-4622-92c6-694683de9212:read\", \"nestedentryfields.871e17fd-93c5-4f99-b004-ebbd5303689b:read\", \"nestedentryfields.b933d220-df03-410e-a4cc-dc86a74d19c9:read\", \"volumes.8618e083-7911-4332-a599-d8c6a8884ed8:read\"]',1,'2024-08-22 14:07:47','2024-08-30 14:14:38','da276327-8079-4620-ad85-b2365f59e93e'),(2,'Private','[\"sites.2eb36cc0-a60a-4071-a815-ce808da649b2:read\", \"sites.ca348b20-8894-41e8-8cbd-4b61bda22ba5:read\", \"elements.drafts:read\", \"elements.revisions:read\", \"elements.inactive:read\", \"sections.663ae8bc-bf43-4af2-9213-eb15474f28c0:read\", \"sections.5583777d-063b-4622-92c6-694683de9212:read\", \"nestedentryfields.871e17fd-93c5-4f99-b004-ebbd5303689b:read\", \"nestedentryfields.b933d220-df03-410e-a4cc-dc86a74d19c9:read\", \"volumes.8618e083-7911-4332-a599-d8c6a8884ed8:read\"]',0,'2024-08-22 14:07:55','2024-08-30 14:14:42','a4cb822f-b5b3-45c4-ba2c-2a4743e275e7');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_awqfwnaxjcigupenbwfknbrfgainntssoknc` (`accessToken`),
  UNIQUE KEY `idx_xlglphhzvyzvhqvhqydmwbfplcojeznmqggi` (`name`),
  KEY `fk_mjefxufmythalavcleziudcovrsuihkcfihj` (`schemaId`),
  CONSTRAINT `fk_mjefxufmythalavcleziudcovrsuihkcfihj` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Private','zkIQgIikhP2RpjQtuGOnd26jMLe0Dq45',1,NULL,'2024-09-04 19:39:44',2,'2024-08-22 14:08:07','2024-09-04 19:39:44','0643b4b0-3f45-44b2-975d-db12ac668de0'),(2,'Public Token','__PUBLIC__',1,NULL,NULL,NULL,'2024-08-26 18:00:46','2024-08-26 18:00:46','99c2ca03-b671-491b-85bf-233472b65f12');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mljecyshuiuipjcmshlptjalccqarmbywlpk` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (34,20,'craft\\imagetransforms\\ImageTransformer','DJI_20240204092448_0006_D-Enhanced-NR.png',NULL,'_30x13_crop_center-center_none',1,0,0,'2024-08-26 18:08:26','2024-08-26 18:08:26','2024-08-26 18:08:27','4cb22438-6e7e-4c5a-bf91-b14d83ea35f5'),(35,20,'craft\\imagetransforms\\ImageTransformer','DJI_20240204092448_0006_D-Enhanced-NR.png',NULL,'_60x27_crop_center-center_none',1,0,0,'2024-08-26 18:08:26','2024-08-26 18:08:26','2024-08-26 18:08:27','c0e25640-f340-4849-a721-3c4c519ae7f3'),(36,20,'craft\\imagetransforms\\ImageTransformer','DJI_20240204092448_0006_D-Enhanced-NR.png',NULL,'_350x159_crop_center-center_none',1,0,0,'2024-08-26 18:10:55','2024-08-26 18:10:55','2024-08-26 18:10:55','eaaaaed7-2b37-4a6d-9a00-dbfb2d1ecb66'),(37,20,'craft\\imagetransforms\\ImageTransformer','DJI_20240204092448_0006_D-Enhanced-NR.png',NULL,'_700x318_crop_center-center_none',1,0,0,'2024-08-26 18:10:55','2024-08-26 18:10:55','2024-08-26 18:10:56','92bbd446-f232-4c0e-bf93-545c03f5be18'),(38,22,'craft\\imagetransforms\\ImageTransformer','Untitled.png',NULL,'_30x15_crop_center-center_none',1,0,0,'2024-08-26 18:11:28','2024-08-26 18:11:28','2024-08-26 18:11:28','a6862b3e-0650-48dd-9d58-fdf33a762b3a'),(39,22,'craft\\imagetransforms\\ImageTransformer','Untitled.png',NULL,'_60x30_crop_center-center_none',1,0,0,'2024-08-26 18:11:28','2024-08-26 18:11:28','2024-08-26 18:11:29','53d0d052-fab3-40ff-af59-c2d59f8929e9');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uaytgrgkpupsjkqecqfmdzjtzzufbjkhldqs` (`name`),
  KEY `idx_fyxxpnkryqarhohtylosggycanugawtzuync` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.3.6','5.3.0.2',0,'gjdonemtfdkc','3@cnurlnrktj','2024-08-22 14:07:09','2024-09-04 19:39:22','ddcb4c31-0cd6-418d-9d03-a57a73d525e0');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cjcoyczqynajcsllwmyximghhlrsmhqhrkgs` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','0e4c85ba-8d62-4ed6-b1bd-8d960a106c55'),(2,'craft','m221101_115859_create_entries_authors_table','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','14bc8f8d-e7b0-4971-a8e4-22d8b9bffef7'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','136ce7a1-3c5e-4162-8464-5644da4cb782'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','7612290c-300a-4c02-8fa1-dafd2835c828'),(5,'craft','m230314_110309_add_authenticator_table','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','c3d34b7e-878d-4c5f-b28d-f34fdb52698a'),(6,'craft','m230314_111234_add_webauthn_table','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','d4bae4fc-7331-4a2b-a571-8d8e72c3ae87'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','2014d22c-62be-49ff-8dae-58f663ff95f3'),(8,'craft','m230511_000000_field_layout_configs','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','f8b45cbb-4363-4a92-8ab4-f7a0d7068337'),(9,'craft','m230511_215903_content_refactor','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','dc6df19f-5e8d-44ef-80ea-210437123fda'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','7657cbff-9525-44a9-b4c7-7e16a5c467c8'),(11,'craft','m230524_000001_entry_type_icons','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','87cdc451-ff29-4e83-8d9b-fa72b59204ab'),(12,'craft','m230524_000002_entry_type_colors','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','668a1701-94d5-439f-a30d-2062f206f79f'),(13,'craft','m230524_220029_global_entry_types','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','03f37a4e-902a-4602-8618-d9d18d635464'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','2c8ed740-56b3-4713-910e-bf486ac4a4dc'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','b2532917-4263-4f98-9884-b234aa928d10'),(16,'craft','m230616_173810_kill_field_groups','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','5bfd56a0-0d51-4bee-8aad-30394dff3b10'),(17,'craft','m230616_183820_remove_field_name_limit','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','8392c427-83af-4999-a3af-8d57eea0bc18'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','e4d8f0d2-c82b-4d71-8671-c6db62068908'),(19,'craft','m230710_162700_element_activity','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','e09f1ff3-b27b-436f-91fc-67632ad2f428'),(20,'craft','m230820_162023_fix_cache_id_type','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','3dc32985-6970-4748-94d4-73a2ac38826b'),(21,'craft','m230826_094050_fix_session_id_type','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','9af771c8-7a47-4012-8889-22584e83de24'),(22,'craft','m230904_190356_address_fields','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','f11f3343-a6d3-4023-8a55-9aed1fcb5f95'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','a2d2f2a2-400c-412d-937f-278f1b0faa4c'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','4a82d14f-e6b1-445f-82e7-b228f8ba1552'),(25,'craft','m231213_030600_element_bulk_ops','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','132a4b48-5097-4f78-8abc-f2aa28129c0f'),(26,'craft','m240129_150719_sites_language_amend_length','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','a735b4ee-2f98-4c0c-ba60-843f35fd69b6'),(27,'craft','m240206_035135_convert_json_columns','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','f5dd6085-8f06-420e-bd5f-bdfee43e595b'),(28,'craft','m240207_182452_address_line_3','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','3454700b-5e3a-4c26-a7d5-7c11a51c818c'),(29,'craft','m240302_212719_solo_preview_targets','2024-08-22 14:07:10','2024-08-22 14:07:10','2024-08-22 14:07:10','fabf24b2-bf0d-45d8-8483-b7326c7c46ee'),(30,'plugin:ckeditor','Install','2024-08-26 17:18:35','2024-08-26 17:18:35','2024-08-26 17:18:35','b2ea54cc-35cb-42ac-996c-14b702a2af01'),(31,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-08-26 17:18:35','2024-08-26 17:18:35','2024-08-26 17:18:35','fbf5effc-c566-4424-8af9-9bc30b420cfb'),(32,'craft','m240619_091352_add_auth_2fa_timestamp','2024-08-26 17:21:10','2024-08-26 17:21:10','2024-08-26 17:21:10','39b1f69b-10e7-49ad-8306-552b48897864'),(33,'craft','m240723_214330_drop_bulkop_fk','2024-08-26 17:21:10','2024-08-26 17:21:10','2024-08-26 17:21:10','70ad1d12-48a4-451f-a9c2-8bdb1e1b8895'),(34,'craft','m240731_053543_soft_delete_fields','2024-08-26 17:21:10','2024-08-26 17:21:10','2024-08-26 17:21:10','f058e01a-7113-48b0-b6d3-633ec5856906'),(35,'craft','m240805_154041_sso_identities','2024-08-26 17:21:10','2024-08-26 17:21:10','2024-08-26 17:21:10','6b37541c-164d-4a08-bb54-6147551420bb'),(36,'plugin:seo','Install','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','45a427da-c8d4-4708-b74c-d0650f987dbc'),(37,'plugin:seo','m180906_152947_add_site_id_to_redirects','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','9c9bc9d2-febd-40eb-933a-c6694fcd23ef'),(38,'plugin:seo','m190114_152300_upgrade_to_new_data_format','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','5369dc0f-3ef5-4bb1-ad36-f8986c07aecd'),(39,'plugin:seo','m200518_110721_add_order_to_redirects','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','818f553c-9c12-411b-92fe-21f3575a2860'),(40,'plugin:seo','m201207_124200_add_product_types_to_sitemap','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','a06105bf-ed75-4446-b6bc-ce2b560266bd');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ovoiwyjdrvhvoeavqxvbwtvfqtswhnvsecju` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'ckeditor','4.0.6','3.0.0.0','2024-08-26 17:18:35','2024-08-26 17:18:35','2024-08-26 17:18:35','865a2c32-a878-4331-a368-a492d5091dd3'),(2,'plausible','3.0.0','2.0.0','2024-08-26 17:18:35','2024-08-26 17:18:35','2024-08-26 17:18:35','79f63d19-fb11-424d-9978-b9bed19e982d'),(3,'seo','v5.0.0-rc5','3.2.0','2024-08-30 16:43:54','2024-08-30 16:43:54','2024-08-30 16:43:54','b91e7dad-d9ee-4ba1-814d-4aec4e74f3e3');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1725478762'),('email.fromEmail','\"daniel@drivebrandstudio.com\"'),('email.fromName','\"Craft 5caffold\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.color','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elementCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.autocapitalize','true'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.autocomplete','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.autocorrect','true'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.class','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.dateAdded','\"2024-08-26T17:25:02+00:00\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.disabled','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.elementCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.id','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.includeInCards','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.inputType','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.instructions','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.label','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.max','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.min','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.name','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.orientation','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.placeholder','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.providesThumbs','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.readonly','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.requirable','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.size','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.step','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.tip','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.title','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.uid','\"05d73b00-2045-4941-805b-de103eac0fae\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.userCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.warning','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.0.width','100'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.dateAdded','\"2024-08-26T17:26:32+00:00\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.elementCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.fieldUid','\"4f44f246-357b-4552-a587-38f11cd9d378\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.handle','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.includeInCards','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.instructions','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.label','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.providesThumbs','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.required','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.tip','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.uid','\"afd9d5f6-4c6c-4c70-8452-acafb6c61ce2\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.userCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.warning','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.1.width','100'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.dateAdded','\"2024-09-03T20:43:43+00:00\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.elementCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.fieldUid','\"cca50fd5-eae7-46d1-a534-225f1a1dd71d\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.handle','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.includeInCards','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.instructions','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.label','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.providesThumbs','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.required','false'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.tip','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.uid','\"ab8b5cc9-692a-4ba3-9007-29f51e4ce344\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.userCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.warning','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.elements.2.width','100'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.name','\"Content\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.uid','\"337f01ac-5651-4ae5-a735-83c9eb5e6bd5\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.fieldLayouts.4d2a3761-91d0-4db9-bd01-15d069258eb8.tabs.0.userCondition','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.handle','\"home\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.hasTitleField','true'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.icon','\"\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.name','\"Home\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.showSlugField','true'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.showStatusField','true'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.slugTranslationKeyFormat','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.slugTranslationMethod','\"site\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.titleFormat','\"\"'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.titleTranslationKeyFormat','null'),('entryTypes.3eed0c77-3b75-46cd-8e31-351f3c83f416.titleTranslationMethod','\"site\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.color','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.autocapitalize','true'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.autocomplete','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.autocorrect','true'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.class','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.dateAdded','\"2024-08-30T13:23:17+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.disabled','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.id','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.inputType','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.max','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.min','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.name','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.orientation','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.placeholder','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.readonly','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.requirable','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.size','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.step','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.title','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.uid','\"741c3acb-9eba-4299-b353-4d89288cc6c9\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.0.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.dateAdded','\"2024-09-04T19:39:22+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.fieldUid','\"cca50fd5-eae7-46d1-a534-225f1a1dd71d\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.handle','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.required','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.uid','\"be32a40f-0223-4e72-b127-daba7fef164c\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.1.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.dateAdded','\"2024-08-30T13:27:04+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.fieldUid','\"2dc0eec0-8212-489c-92c3-5ef43da4bf6f\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.handle','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.required','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.uid','\"b247bec1-e40a-4d2b-a7e9-ae3be987fa0f\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.2.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.dateAdded','\"2024-08-30T13:27:04+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.fieldUid','\"177c74bc-bb8e-490b-b0f8-3cc4515e7af0\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.handle','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.required','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.uid','\"6454f755-a0a7-4507-8fba-9a8abf925407\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.3.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.dateAdded','\"2024-08-30T13:27:04+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.fieldUid','\"2aadf49b-1991-42e6-b44a-67b81ca12c34\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.handle','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.required','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.uid','\"d800e333-e30d-40ad-b909-a6207c830501\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.4.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.dateAdded','\"2024-08-30T13:42:40+00:00\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.elementCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.fieldUid','\"b933d220-df03-410e-a4cc-dc86a74d19c9\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.handle','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.includeInCards','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.instructions','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.label','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.providesThumbs','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.required','false'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.tip','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.uid','\"a029caf8-e5d2-46d0-92e6-24e8105b4006\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.warning','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.elements.5.width','100'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.name','\"Content\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.uid','\"00d132d0-ba49-497d-a6b1-961e3543a389\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.fieldLayouts.bf9ebec4-a500-4811-8e57-7a76e355da50.tabs.0.userCondition','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.handle','\"blog\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.hasTitleField','true'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.icon','\"\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.name','\"Blog\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.showSlugField','true'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.showStatusField','true'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.slugTranslationKeyFormat','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.slugTranslationMethod','\"site\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.titleFormat','\"\"'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.titleTranslationKeyFormat','null'),('entryTypes.48c74af2-dc9f-4a19-8a9a-5e72de6b2950.titleTranslationMethod','\"site\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.color','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elementCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.autocapitalize','true'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.autocomplete','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.autocorrect','true'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.class','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.dateAdded','\"2024-08-30T13:38:32+00:00\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.disabled','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.elementCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.id','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.includeInCards','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.inputType','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.instructions','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.label','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.max','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.min','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.name','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.orientation','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.placeholder','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.providesThumbs','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.readonly','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.requirable','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.size','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.step','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.tip','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.title','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.uid','\"1d1066c5-a235-4b95-b769-ca31d14ff483\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.userCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.warning','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.0.width','100'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.dateAdded','\"2024-08-30T13:40:27+00:00\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.elementCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.fieldUid','\"2dc0eec0-8212-489c-92c3-5ef43da4bf6f\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.handle','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.includeInCards','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.instructions','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.label','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.providesThumbs','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.required','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.tip','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.uid','\"94061721-49f3-43f3-aeb9-ef102fd27f43\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.userCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.warning','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.elements.1.width','100'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.name','\"Content\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.uid','\"9cb0214a-dee7-4c1e-b3f8-29519dbc416f\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.fieldLayouts.f6df1b18-a5d7-4bb6-b3f1-df14de36df46.tabs.0.userCondition','null'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.handle','\"subhead\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.hasTitleField','false'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.icon','\"\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.name','\"Subhead\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.showSlugField','true'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.showStatusField','true'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.slugTranslationKeyFormat','\"\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.slugTranslationMethod','\"site\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.titleFormat','\"\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.titleTranslationKeyFormat','\"\"'),('entryTypes.7c0dae6e-f903-4671-869a-4b207ce5f4f4.titleTranslationMethod','\"site\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.color','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elementCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.autocapitalize','true'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.autocomplete','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.autocorrect','true'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.class','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.dateAdded','\"2024-08-30T13:39:35+00:00\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.disabled','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.elementCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.id','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.includeInCards','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.inputType','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.instructions','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.label','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.max','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.min','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.name','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.orientation','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.placeholder','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.providesThumbs','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.readonly','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.requirable','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.size','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.step','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.tip','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.title','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.uid','\"c17c88fd-366f-4921-afbe-bf2cbbf15a36\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.userCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.warning','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.0.width','100'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.dateAdded','\"2024-08-30T13:41:20+00:00\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.elementCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.fieldUid','\"871e17fd-93c5-4f99-b004-ebbd5303689b\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.handle','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.includeInCards','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.instructions','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.label','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.providesThumbs','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.required','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.tip','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.uid','\"2d847eee-7826-49b9-9156-514fcd6290db\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.userCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.warning','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.elements.1.width','100'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.name','\"Content\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.uid','\"85a51592-60ea-4318-bbd5-3be118b97280\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.fieldLayouts.1f6ab771-bb64-4864-a666-2074c232c5a4.tabs.0.userCondition','null'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.handle','\"text\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.hasTitleField','false'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.icon','\"\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.name','\"Text\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.showSlugField','true'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.showStatusField','true'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.slugTranslationKeyFormat','\"\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.slugTranslationMethod','\"site\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.titleFormat','\"\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.titleTranslationKeyFormat','\"\"'),('entryTypes.b9f9ee47-0657-457a-b3e2-adf8f45280fc.titleTranslationMethod','\"site\"'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.columnSuffix','null'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.handle','\"date\"'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.instructions','null'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.name','\"Date\"'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.searchable','false'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.max','null'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.min','null'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.minuteIncrement','30'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.showDate','true'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.showTime','false'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.settings.showTimeZone','false'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.translationKeyFormat','null'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.translationMethod','\"none\"'),('fields.177c74bc-bb8e-490b-b0f8-3cc4515e7af0.type','\"craft\\\\fields\\\\Date\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.columnSuffix','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.handle','\"thumbnail\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.instructions','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.name','\"Thumbnail\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.searchable','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.allowedKinds','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.allowSelfRelations','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.allowSubfolders','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.allowUploads','true'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.branchLimit','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.defaultUploadLocationSource','\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.defaultUploadLocationSubpath','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.maintainHierarchy','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.maxRelations','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.minRelations','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.previewMode','\"full\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.restrictedDefaultUploadSubpath','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.restrictedLocationSource','\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.restrictedLocationSubpath','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.restrictFiles','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.restrictLocation','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.selectionLabel','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.showCardsInGrid','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.showSiteMenu','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.showUnpermittedFiles','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.showUnpermittedVolumes','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.sources','\"*\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.targetSiteId','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.validateRelatedElements','false'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.settings.viewMode','\"list\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.translationKeyFormat','null'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.translationMethod','\"none\"'),('fields.2aadf49b-1991-42e6-b44a-67b81ca12c34.type','\"craft\\\\fields\\\\Assets\"'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.columnSuffix','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.handle','\"summary\"'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.instructions','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.name','\"Summary\"'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.searchable','false'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.byteLimit','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.charLimit','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.code','false'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.initialRows','4'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.multiline','false'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.placeholder','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.settings.uiMode','\"normal\"'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.translationKeyFormat','null'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.translationMethod','\"none\"'),('fields.2dc0eec0-8212-489c-92c3-5ef43da4bf6f.type','\"craft\\\\fields\\\\PlainText\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.columnSuffix','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.handle','\"images\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.instructions','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.name','\"Images\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.searchable','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.allowedKinds','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.allowSelfRelations','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.allowSubfolders','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.allowUploads','true'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.branchLimit','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.defaultUploadLocationSource','\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.defaultUploadLocationSubpath','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.maintainHierarchy','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.maxRelations','15'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.minRelations','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.previewMode','\"full\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.restrictedDefaultUploadSubpath','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.restrictedLocationSource','\"volume:8618e083-7911-4332-a599-d8c6a8884ed8\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.restrictedLocationSubpath','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.restrictFiles','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.restrictLocation','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.selectionLabel','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.showCardsInGrid','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.showSiteMenu','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.showUnpermittedFiles','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.showUnpermittedVolumes','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.sources','\"*\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.targetSiteId','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.validateRelatedElements','false'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.settings.viewMode','\"list\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.translationKeyFormat','null'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.translationMethod','\"none\"'),('fields.4f44f246-357b-4552-a587-38f11cd9d378.type','\"craft\\\\fields\\\\Assets\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.columnSuffix','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.handle','\"articleText\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.instructions','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.name','\"Article Text\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.searchable','false'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.availableTransforms','\"\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.availableVolumes','\"*\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.ckeConfig','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.createButtonLabel','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.defaultTransform','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.enableSourceEditingForNonAdmins','false'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.purifierConfig','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.purifyHtml','true'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.showUnpermittedFiles','false'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.showUnpermittedVolumes','false'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.showWordCount','false'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.settings.wordLimit','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.translationKeyFormat','null'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.translationMethod','\"none\"'),('fields.871e17fd-93c5-4f99-b004-ebbd5303689b.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.columnSuffix','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.handle','\"articleContent\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.instructions','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.name','\"Article Content\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.searchable','false'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.createButtonLabel','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.entryTypes.0','\"7c0dae6e-f903-4671-869a-4b207ce5f4f4\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.entryTypes.1','\"b9f9ee47-0657-457a-b3e2-adf8f45280fc\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.includeTableView','false'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.maxEntries','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.minEntries','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.pageSize','50'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.propagationKeyFormat','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.propagationMethod','\"all\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.showCardsInGrid','false'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.settings.viewMode','\"cards\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.translationKeyFormat','null'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.translationMethod','\"site\"'),('fields.b933d220-df03-410e-a4cc-dc86a74d19c9.type','\"craft\\\\fields\\\\Matrix\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.columnSuffix','null'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.handle','\"seo\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.instructions','null'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.name','\"SEO\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.searchable','false'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.description','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.hideSocial','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.0','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.1','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.2','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.3','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.4','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.robots.5','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.socialImage','\"\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.suffixAsPrefix','null'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.0.0','\"key\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.0.1','\"1\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.1.0','\"locked\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.1.1','\"0\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.2.0','\"template\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.0.__assoc__.2.1','\"{title}\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.0.0','\"key\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.0.1','\"2\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.1.0','\"locked\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.1.1','\"1\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.2.0','\"template\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.title.1.__assoc__.2.1','\" - {{ siteName }}\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.settings.titleSuffix','null'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.translationKeyFormat','null'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.translationMethod','\"none\"'),('fields.cca50fd5-eae7-46d1-a534-225f1a1dd71d.type','\"ether\\\\seo\\\\fields\\\\SeoField\"'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.columnSuffix','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.handle','\"article\"'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.instructions','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.name','\"Article\"'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.searchable','false'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.byteLimit','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.charLimit','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.code','false'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.initialRows','4'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.multiline','false'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.placeholder','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.settings.uiMode','\"normal\"'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.translationKeyFormat','null'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.translationMethod','\"none\"'),('fields.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6.type','\"craft\\\\fields\\\\PlainText\"'),('fs.public.hasUrls','true'),('fs.public.name','\"Public\"'),('fs.public.settings.path','\"public/images\"'),('fs.public.type','\"craft\\\\fs\\\\Local\"'),('fs.public.url','\"@web/public/images\"'),('graphql.publicToken.enabled','true'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.isPublic','false'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.name','\"Private\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.0','\"sites.2eb36cc0-a60a-4071-a815-ce808da649b2:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.1','\"sites.ca348b20-8894-41e8-8cbd-4b61bda22ba5:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.2','\"elements.drafts:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.3','\"elements.revisions:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.4','\"elements.inactive:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.5','\"sections.663ae8bc-bf43-4af2-9213-eb15474f28c0:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.6','\"sections.5583777d-063b-4622-92c6-694683de9212:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.7','\"nestedentryfields.871e17fd-93c5-4f99-b004-ebbd5303689b:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.8','\"nestedentryfields.b933d220-df03-410e-a4cc-dc86a74d19c9:read\"'),('graphql.schemas.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7.scope.9','\"volumes.8618e083-7911-4332-a599-d8c6a8884ed8:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.isPublic','true'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.name','\"Public Schema\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.0','\"sites.2eb36cc0-a60a-4071-a815-ce808da649b2:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.1','\"sites.ca348b20-8894-41e8-8cbd-4b61bda22ba5:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.2','\"elements.drafts:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.3','\"elements.revisions:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.4','\"elements.inactive:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.5','\"sections.663ae8bc-bf43-4af2-9213-eb15474f28c0:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.6','\"sections.5583777d-063b-4622-92c6-694683de9212:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.7','\"nestedentryfields.871e17fd-93c5-4f99-b004-ebbd5303689b:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.8','\"nestedentryfields.b933d220-df03-410e-a4cc-dc86a74d19c9:read\"'),('graphql.schemas.da276327-8079-4620-ad85-b2365f59e93e.scope.9','\"volumes.8618e083-7911-4332-a599-d8c6a8884ed8:read\"'),('meta.__names__.177c74bc-bb8e-490b-b0f8-3cc4515e7af0','\"Date\"'),('meta.__names__.2aadf49b-1991-42e6-b44a-67b81ca12c34','\"Thumbnail\"'),('meta.__names__.2dc0eec0-8212-489c-92c3-5ef43da4bf6f','\"Summary\"'),('meta.__names__.2eb36cc0-a60a-4071-a815-ce808da649b2','\"Craft 5caffold\"'),('meta.__names__.3eed0c77-3b75-46cd-8e31-351f3c83f416','\"Home\"'),('meta.__names__.48c74af2-dc9f-4a19-8a9a-5e72de6b2950','\"Blog\"'),('meta.__names__.4f44f246-357b-4552-a587-38f11cd9d378','\"Images\"'),('meta.__names__.5583777d-063b-4622-92c6-694683de9212','\"Blog\"'),('meta.__names__.663ae8bc-bf43-4af2-9213-eb15474f28c0','\"Home\"'),('meta.__names__.7c0dae6e-f903-4671-869a-4b207ce5f4f4','\"Subhead\"'),('meta.__names__.8618e083-7911-4332-a599-d8c6a8884ed8','\"Images\"'),('meta.__names__.871e17fd-93c5-4f99-b004-ebbd5303689b','\"Article Text\"'),('meta.__names__.a033033c-2320-4124-996c-2e6e2c1b2869','\"Craft 5caffold\"'),('meta.__names__.a4cb822f-b5b3-45c4-ba2c-2a4743e275e7','\"Private\"'),('meta.__names__.b933d220-df03-410e-a4cc-dc86a74d19c9','\"Article Content\"'),('meta.__names__.b9f9ee47-0657-457a-b3e2-adf8f45280fc','\"Text\"'),('meta.__names__.cca50fd5-eae7-46d1-a534-225f1a1dd71d','\"SEO\"'),('meta.__names__.da276327-8079-4620-ad85-b2365f59e93e','\"Public Schema\"'),('meta.__names__.ebf1e9e6-4b9c-409f-9820-ac7c6cd121c6','\"Article\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.plausible.edition','\"standard\"'),('plugins.plausible.enabled','true'),('plugins.plausible.schemaVersion','\"2.0.0\"'),('plugins.seo.edition','\"standard\"'),('plugins.seo.enabled','true'),('plugins.seo.schemaVersion','\"3.2.0\"'),('sections.5583777d-063b-4622-92c6-694683de9212.defaultPlacement','\"end\"'),('sections.5583777d-063b-4622-92c6-694683de9212.enableVersioning','true'),('sections.5583777d-063b-4622-92c6-694683de9212.entryTypes.0','\"48c74af2-dc9f-4a19-8a9a-5e72de6b2950\"'),('sections.5583777d-063b-4622-92c6-694683de9212.handle','\"blog\"'),('sections.5583777d-063b-4622-92c6-694683de9212.maxAuthors','1'),('sections.5583777d-063b-4622-92c6-694683de9212.name','\"Blog\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.1.1','\"http://localhost:3000/api/preview?entryUid={canonicalUid}\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.5583777d-063b-4622-92c6-694683de9212.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.5583777d-063b-4622-92c6-694683de9212.propagationMethod','\"all\"'),('sections.5583777d-063b-4622-92c6-694683de9212.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.enabledByDefault','true'),('sections.5583777d-063b-4622-92c6-694683de9212.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.hasUrls','true'),('sections.5583777d-063b-4622-92c6-694683de9212.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.template','null'),('sections.5583777d-063b-4622-92c6-694683de9212.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.uriFormat','\"blog/{slug}\"'),('sections.5583777d-063b-4622-92c6-694683de9212.type','\"channel\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.defaultPlacement','\"end\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.enableVersioning','true'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.entryTypes.0','\"3eed0c77-3b75-46cd-8e31-351f3c83f416\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.handle','\"home\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.maxAuthors','1'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.name','\"Home\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.propagationMethod','\"all\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.enabledByDefault','true'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.hasUrls','true'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.template','null'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.siteSettings.2eb36cc0-a60a-4071-a815-ce808da649b2.uriFormat','\"__home__\"'),('sections.663ae8bc-bf43-4af2-9213-eb15474f28c0.type','\"single\"'),('siteGroups.a033033c-2320-4124-996c-2e6e2c1b2869.name','\"Craft 5caffold\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.enabled','true'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.handle','\"default\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.hasUrls','true'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.language','\"en-US\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.name','\"Craft 5caffold\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.primary','true'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.siteGroup','\"a033033c-2320-4124-996c-2e6e2c1b2869\"'),('sites.2eb36cc0-a60a-4071-a815-ce808da649b2.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Craft 5caffold\"'),('system.schemaVersion','\"5.3.0.2\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.altTranslationKeyFormat','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.altTranslationMethod','\"none\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elementCondition','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.autocapitalize','true'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.autocomplete','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.autocorrect','true'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.class','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.dateAdded','\"2024-08-26T17:28:44+00:00\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.disabled','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.elementCondition','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.id','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.includeInCards','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.inputType','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.instructions','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.label','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.max','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.min','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.name','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.orientation','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.placeholder','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.providesThumbs','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.readonly','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.requirable','false'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.size','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.step','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.tip','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.title','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.uid','\"7b0fa929-d748-4dd1-8b17-8e3ddcd3ed56\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.userCondition','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.warning','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.elements.0.width','100'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.name','\"Content\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.uid','\"c0903bb8-20dd-4582-b422-be90843b70bf\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fieldLayouts.223262e3-ab4c-4fc3-8ccf-a53023bae4a0.tabs.0.userCondition','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.fs','\"public\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.handle','\"images\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.name','\"Images\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.sortOrder','1'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.subpath','\"\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.titleTranslationKeyFormat','null'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.titleTranslationMethod','\"site\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.transformFs','\"public\"'),('volumes.8618e083-7911-4332-a599-d8c6a8884ed8.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_vicnwfldgljpyohgrmkqebheqahkweelwwru` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_lpwvjwdzgjuryofzkukujdnphebqyrornxdg` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hgxvnmelvfcolbfqrxhkgghrqcbdmgxbovlx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_groayhypdrsjzizgbyytrfmnytumszixnqtr` (`sourceId`),
  KEY `idx_wuqkiepjngbrlfcsqbeaponbvywwuszddqms` (`targetId`),
  KEY `idx_fiilyxrcwvedrqxxwhbhkzhiaxdnfdvblwln` (`sourceSiteId`),
  CONSTRAINT `fk_bhoibjapgootrjpejlxkgpjyxtiducrecrlf` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gcecdmcyagjwmjtarzdgwnwgkvcljhikthum` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xerypvcjxbvzuhwoxeqjmonrsduoszlfueva` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (25,1,17,NULL,15,1,'2024-08-26 17:47:23','2024-08-26 17:47:23','11943b18-d3f9-4426-b79f-68733ab36227'),(26,1,17,NULL,14,2,'2024-08-26 17:47:23','2024-08-26 17:47:23','cb763cd3-89b9-49d9-ad28-9454bfdb341f'),(27,1,17,NULL,13,3,'2024-08-26 17:47:23','2024-08-26 17:47:23','8d153fbe-0746-4747-92da-1f27d10cad71'),(28,1,17,NULL,12,4,'2024-08-26 17:47:23','2024-08-26 17:47:23','05a2891a-7100-4548-82eb-b772be1d48e2'),(29,1,17,NULL,11,5,'2024-08-26 17:47:23','2024-08-26 17:47:23','b2297d6f-ff2d-42bd-81dd-e0b5e70294a9'),(30,1,17,NULL,10,6,'2024-08-26 17:47:23','2024-08-26 17:47:23','9e468d16-30c4-4459-b560-c59a0b06812a'),(31,1,17,NULL,9,7,'2024-08-26 17:47:23','2024-08-26 17:47:23','5f95b681-b2c3-4c1f-a34d-58f3585d1854'),(32,1,17,NULL,8,8,'2024-08-26 17:47:23','2024-08-26 17:47:23','470fd8e7-42d3-485b-9288-4103ecd34256'),(33,1,17,NULL,7,9,'2024-08-26 17:47:23','2024-08-26 17:47:23','44e71744-d99b-4aae-b45b-b0c3a55b82a1'),(34,1,17,NULL,6,10,'2024-08-26 17:47:23','2024-08-26 17:47:23','bc5f0155-80be-45ac-9d35-79bdc4bd4d3d'),(35,1,17,NULL,5,11,'2024-08-26 17:47:23','2024-08-26 17:47:23','c2737d2c-e29b-4410-87d2-bb795b0b80ca'),(36,1,17,NULL,4,12,'2024-08-26 17:47:23','2024-08-26 17:47:23','58adab76-cf46-41ed-a724-5e90c1541a8d'),(37,1,21,NULL,15,1,'2024-08-26 18:11:21','2024-08-26 18:11:21','2537f030-710a-4f53-9264-b2595e3c3b89'),(38,1,21,NULL,14,2,'2024-08-26 18:11:21','2024-08-26 18:11:21','1b829614-14bf-4881-8aa2-a85bb37c6f0a'),(39,1,21,NULL,13,3,'2024-08-26 18:11:21','2024-08-26 18:11:21','ccb105f6-c1a5-4ccb-b845-b1513878fdfa'),(40,1,21,NULL,12,4,'2024-08-26 18:11:21','2024-08-26 18:11:21','b342e575-74bd-449b-b3fe-09720bbb95a9'),(41,1,21,NULL,11,5,'2024-08-26 18:11:21','2024-08-26 18:11:21','743be47d-213a-483d-910a-c380053eb466'),(42,1,21,NULL,10,6,'2024-08-26 18:11:21','2024-08-26 18:11:21','49e7e6cd-4a0f-41c9-afc0-4ae464440b7d'),(43,1,21,NULL,9,7,'2024-08-26 18:11:21','2024-08-26 18:11:21','1a0a893a-78fb-494a-a3d1-d0861a00874d'),(44,1,21,NULL,8,8,'2024-08-26 18:11:21','2024-08-26 18:11:21','52e200b4-0cea-484e-a064-40c7e3ff68b1'),(45,1,21,NULL,7,9,'2024-08-26 18:11:21','2024-08-26 18:11:21','827e4a5c-a359-4c36-9553-e5f3b3d89319'),(46,1,21,NULL,6,10,'2024-08-26 18:11:21','2024-08-26 18:11:21','36b093d1-7fdb-4712-b39b-e6b498846796'),(47,1,21,NULL,5,11,'2024-08-26 18:11:21','2024-08-26 18:11:21','2f73e0a6-136c-4d95-8540-bb20aee7f7e7'),(48,1,21,NULL,4,12,'2024-08-26 18:11:21','2024-08-26 18:11:21','833a8c5c-024e-4308-adf6-938df1c60dc7'),(52,1,2,NULL,22,1,'2024-08-26 18:15:03','2024-08-26 18:15:03','907e791f-433e-42b1-a6e4-fabc03163daf'),(53,1,2,NULL,20,2,'2024-08-26 18:15:03','2024-08-26 18:15:03','da423d83-7bea-4d29-b1e9-a4c744a0efe5'),(54,1,27,NULL,22,1,'2024-08-26 18:15:03','2024-08-26 18:15:03','139403b3-ef49-4a5a-9821-f50d4aaf33cf'),(55,1,27,NULL,20,2,'2024-08-26 18:15:03','2024-08-26 18:15:03','a96a2cb4-73e0-4d33-96d3-3d592993872e'),(56,4,28,NULL,22,1,'2024-08-30 13:28:54','2024-08-30 13:28:54','e4549370-ce05-468b-8c74-315565b4a7df'),(57,4,29,NULL,22,1,'2024-08-30 13:29:01','2024-08-30 13:29:01','da303ac5-c5e8-467d-bc1f-25f44cbefdf4'),(59,4,35,NULL,22,1,'2024-08-30 13:44:07','2024-08-30 13:44:07','e24319e8-ad21-4f2b-920e-f6ba802743f4'),(61,4,43,NULL,22,1,'2024-08-30 15:04:37','2024-08-30 15:04:37','944622c8-d52e-41a9-9f81-52daba8b7fa0'),(62,1,48,NULL,22,1,'2024-08-30 18:28:06','2024-08-30 18:28:06','09e1d9fd-759b-47ef-9772-5ceac90e3471'),(63,1,48,NULL,20,2,'2024-08-30 18:28:06','2024-08-30 18:28:06','a36710f2-4d9e-4280-9f3e-0e3253efa05d'),(64,1,49,NULL,22,1,'2024-08-30 18:28:39','2024-08-30 18:28:39','c1b5d1fc-9b52-4265-94fb-0faabe0a70cd'),(65,1,49,NULL,20,2,'2024-08-30 18:28:39','2024-08-30 18:28:39','c6e7353b-4699-4006-8146-c9f23d073148'),(66,1,50,NULL,22,1,'2024-09-03 20:35:08','2024-09-03 20:35:08','14291791-5081-4cfb-9727-5c9b52e5e84b'),(67,1,50,NULL,20,2,'2024-09-03 20:35:08','2024-09-03 20:35:08','7f67c4b8-1ce8-4eed-99af-80ac0a9586ed'),(70,1,52,NULL,22,1,'2024-09-04 18:24:55','2024-09-04 18:24:55','56c8cfb5-17a3-4476-a6ac-57e2937a5ad4'),(71,1,52,NULL,20,2,'2024-09-04 18:24:55','2024-09-04 18:24:55','8b4a5afd-2038-4642-b922-c44b67111cac'),(74,1,54,NULL,22,1,'2024-09-04 18:25:34','2024-09-04 18:25:34','c26731e3-9fc8-4550-95fd-b05817d48b63'),(75,1,54,NULL,20,2,'2024-09-04 18:25:34','2024-09-04 18:25:34','c5aceaac-398c-4d79-807e-7f0c16385e12'),(76,4,55,NULL,22,1,'2024-09-04 19:39:31','2024-09-04 19:39:31','b6693f26-2ea4-4d2f-bc6d-f45fdd2ecb37');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('105540c','@craft/web/assets/conditionbuilder/dist'),('1236516b','@craft/web/assets/d3/dist'),('127daeb3','@craft/web/assets/updateswidget/dist'),('1442ee39','@craft/web/assets/axios/dist'),('195758dc','@craft/web/assets/iframeresizer/dist'),('1a77a901','@craft/web/assets/axios/dist'),('2108d0e2','@craft/web/assets/pluginstore/dist'),('232ef8f5','@craft/web/assets/tailwindreset/dist'),('243b42d7','@craft/web/assets/selectize/dist'),('2646a7a7','@craft/web/assets/cp/dist'),('2823c58','@craft/web/assets/recententries/dist'),('2873e09f','@craft/web/assets/cp/dist'),('2a0e05ef','@craft/web/assets/selectize/dist'),('2cc7ecdd','@craft/web/assets/recententries/dist'),('2d1bbfcd','@craft/web/assets/tailwindreset/dist'),('2f3d97da','@craft/web/assets/pluginstore/dist'),('317b5d6f','@craft/web/assets/fieldsettings/dist'),('320d390e','@craft/web/assets/updateswidget/dist'),('3246c6d6','@craft/web/assets/d3/dist'),('34327984','@craft/web/assets/axios/dist'),('35e6f48','@craft/web/assets/tailwindreset/dist'),('37128859','@craft/web/assets/iframeresizer/dist'),('3927cf61','@craft/web/assets/iframeresizer/dist'),('3b226d55','@craft/web/assets/generalsettings/dist'),('3c387e36','@craft/web/assets/updateswidget/dist'),('3c7381ee','@craft/web/assets/d3/dist'),('3f4e1a57','@craft/web/assets/fieldsettings/dist'),('42dbd9d6','@craft/web/assets/fabric/dist'),('442c3e44','@craft/web/assets/garnish/dist'),('44bd56a','@craft/web/assets/selectize/dist'),('4a19797c','@craft/web/assets/garnish/dist'),('501b03ff','@craft/web/assets/focalpoint/dist'),('509e99a2','@craft/web/assets/userpermissions/dist'),('529ae330','@craft/web/assets/graphiql/dist'),('55a27dbb','@craft/web/assets/admintable/dist'),('5743d3f','@craft/web/assets/updater/dist'),('5b973a83','@craft/web/assets/admintable/dist'),('5cafa408','@craft/web/assets/graphiql/dist'),('62ab4e6b','@craft/web/assets/fabric/dist'),('6a69eec1','@craft/web/assets/garnish/dist'),('6c594a76','@craft/web/assets/sites/dist'),('6c9e0953','@craft/web/assets/fabric/dist'),('70ee0e1f','@craft/web/assets/userpermissions/dist'),('7281d855','@craft/web/assets/utilities/dist'),('75622275','@craft/web/assets/queuemanager/dist'),('7b57654d','@craft/web/assets/queuemanager/dist'),('7be7ad3e','@craft/web/assets/admintable/dist'),('7cb49f6d','@craft/web/assets/utilities/dist'),('7edb4927','@craft/web/assets/userpermissions/dist'),('800537c2','@craft/web/assets/jquerytouchevents/dist'),('8037722','@craft/web/assets/cp/dist'),('8056e8a0','@craft/web/assets/jquerypayment/dist'),('85c1ea17','@craft/web/assets/velocity/dist'),('8ac465fe','@craft/web/assets/feed/dist'),('91e1324c','@craft/web/assets/vue/dist'),('9248e2fb','@craft/web/assets/picturefill/dist'),('930f557f','@craft/web/assets/timepicker/dist'),('95a1cf07','@craft/web/assets/craftsupport/dist'),('97c518c3','@craft/web/assets/xregexp/dist'),('99f05ffb','@craft/web/assets/xregexp/dist'),('9b94883f','@craft/web/assets/craftsupport/dist'),('9c7da5c3','@craft/web/assets/picturefill/dist'),('9d3a1247','@craft/web/assets/timepicker/dist'),('a0267f1d','@craft/web/assets/jquerypayment/dist'),('a075a07f','@craft/web/assets/jquerytouchevents/dist'),('a4273f85','@craft/web/assets/assetindexes/dist'),('a481b57b','@craft/web/assets/feed/dist'),('a5b17daa','@craft/web/assets/velocity/dist'),('aaad323b','@craft/web/assets/clearcaches/dist'),('aab4f243','@craft/web/assets/feed/dist'),('ab843a92','@craft/web/assets/velocity/dist'),('ae133825','@craft/web/assets/jquerypayment/dist'),('ae40e747','@craft/web/assets/jquerytouchevents/dist'),('b191a5f1','@craft/web/assets/vue/dist'),('b1c955ae','@craft/web/assets/editsection/dist'),('b37fc2c2','@craft/web/assets/timepicker/dist'),('b417a07','@craft/web/assets/updater/dist'),('b5d158ba','@craft/web/assets/craftsupport/dist'),('b7b58f7e','@craft/web/assets/xregexp/dist'),('bc0d327e','@craft/web/assets/picturefill/dist'),('bfa4e2c9','@craft/web/assets/vue/dist'),('bffc1296','@craft/web/assets/editsection/dist'),('c26405d5','@craft/web/assets/fileupload/dist'),('c822bfdd','@ether/seo/web/assets'),('c90cfaa4','@craft/ckeditor/web/assets/ckeconfig/dist'),('c914113f','@craft/web/assets/htmx/dist'),('cb77b60','@craft/web/assets/recententries/dist'),('d3185c80','@craft/web/assets/elementresizedetector/dist'),('d3f7d488','@craft/web/assets/dashboard/dist'),('d6f84368','@bower/jquery/dist'),('dc1fd37e','@craft/web/assets/jqueryui/dist'),('ddc293b0','@craft/web/assets/dashboard/dist'),('e2149268','@craft/web/assets/fileupload/dist'),('e413cce6','@craft/web/assets/updates/dist'),('e7a9f639','@craft/web/assets/prismjs/dist'),('e99cb101','@craft/web/assets/prismjs/dist'),('ea268bde','@craft/web/assets/updates/dist'),('ec21d550','@craft/web/assets/fileupload/dist'),('f25a03fb','@craft/web/assets/jqueryui/dist'),('f2dbd863','@nystudio107/codeeditor/web/assets/dist'),('f3874335','@craft/web/assets/dashboard/dist'),('f688d4d5','@bower/jquery/dist'),('f8bd93ed','@bower/jquery/dist'),('fc6f44c3','@craft/web/assets/jqueryui/dist'),('fcc302e3','@craft/ckeditor/web/assets/ckeditor/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ykiqcvjozhkxtbictkonjdiljtvbybsdfhkq` (`canonicalId`,`num`),
  KEY `fk_kknrxnhvydqghmsdgguqgwfhayuarwodpirc` (`creatorId`),
  CONSTRAINT `fk_dvgzbynleocjbifaverkfnayccybgwxecnnb` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kknrxnhvydqghmsdgguqgwfhayuarwodpirc` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,'Applied “Draft 1”'),(3,2,1,3,''),(4,2,1,4,'Applied “Draft 1”'),(5,2,1,5,''),(6,2,1,6,'Applied “Draft 1”'),(7,28,1,1,''),(8,28,1,2,'Applied “Draft 1”'),(9,33,1,1,NULL),(10,34,1,1,NULL),(11,28,1,3,'Applied “Draft 1”'),(12,33,1,2,NULL),(13,34,1,2,NULL),(14,41,1,1,NULL),(15,42,1,1,NULL),(16,2,1,7,''),(17,2,1,8,''),(18,2,1,9,NULL),(19,2,1,10,'Applied “Draft 1”'),(20,2,1,11,'Applied “Draft 1”'),(21,28,1,4,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_dwbyortkuvuhjfxvypdsvvfsovjfklpoqitk` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,2,' daniel drivebrandstudio com '),(1,'firstname',0,2,''),(1,'fullname',0,2,''),(1,'lastname',0,2,''),(1,'slug',0,2,''),(1,'username',0,2,' admin '),(2,'slug',0,1,' home '),(2,'slug',0,2,' home '),(2,'title',0,1,' home '),(2,'title',0,2,' hometestettest '),(4,'alt',0,1,''),(4,'alt',0,2,''),(4,'extension',0,1,' jpeg '),(4,'extension',0,2,' jpeg '),(4,'filename',0,1,' designer 1 jpeg '),(4,'filename',0,2,' designer 1 jpeg '),(4,'kind',0,1,' image '),(4,'kind',0,2,' image '),(4,'slug',0,1,''),(4,'slug',0,2,''),(4,'title',0,1,' designer 1 '),(4,'title',0,2,' designer 1 '),(5,'alt',0,1,''),(5,'alt',0,2,''),(5,'extension',0,1,' jpeg '),(5,'extension',0,2,' jpeg '),(5,'filename',0,1,' designer jpeg '),(5,'filename',0,2,' designer jpeg '),(5,'kind',0,1,' image '),(5,'kind',0,2,' image '),(5,'slug',0,1,''),(5,'slug',0,2,''),(5,'title',0,1,' designer '),(5,'title',0,2,' designer '),(6,'alt',0,1,''),(6,'alt',0,2,''),(6,'extension',0,1,' png '),(6,'extension',0,2,' png '),(6,'filename',0,1,' sasquatch png '),(6,'filename',0,2,' sasquatch png '),(6,'kind',0,1,' image '),(6,'kind',0,2,' image '),(6,'slug',0,1,''),(6,'slug',0,2,''),(6,'title',0,1,' sasquatch '),(6,'title',0,2,' sasquatch '),(7,'alt',0,1,''),(7,'alt',0,2,''),(7,'extension',0,1,' png '),(7,'extension',0,2,' png '),(7,'filename',0,1,' dji 20240204092448 0006 d enhanced nr png '),(7,'filename',0,2,' dji 20240204092448 0006 d enhanced nr png '),(7,'kind',0,1,' image '),(7,'kind',0,2,' image '),(7,'slug',0,1,''),(7,'slug',0,2,''),(7,'title',0,1,' dji 20240204092448 0006 d enhanced nr '),(7,'title',0,2,' dji 20240204092448 0006 d enhanced nr '),(8,'alt',0,1,''),(8,'alt',0,2,''),(8,'extension',0,1,' jpg '),(8,'extension',0,2,' jpg '),(8,'filename',0,1,' 201918 01 jpg '),(8,'filename',0,2,' 201918 01 jpg '),(8,'kind',0,1,' image '),(8,'kind',0,2,' image '),(8,'slug',0,1,''),(8,'slug',0,2,''),(8,'title',0,1,' 201918 01 '),(8,'title',0,2,' 201918 01 '),(9,'alt',0,1,''),(9,'alt',0,2,''),(9,'extension',0,1,' jpg '),(9,'extension',0,2,' jpg '),(9,'filename',0,1,' jekyll 08312017 0379 edit 3d807bf7 96ad 4f46 a0f974bf561eccdf cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f jpg '),(9,'filename',0,2,' jekyll 08312017 0379 edit 3d807bf7 96ad 4f46 a0f974bf561eccdf cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f jpg '),(9,'kind',0,1,' image '),(9,'kind',0,2,' image '),(9,'slug',0,1,''),(9,'slug',0,2,''),(9,'title',0,1,' jekyll 08312017 0379 edit 3 d807 bf7 96 ad 4 f46 a0 f974 bf561 eccdf cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f '),(9,'title',0,2,' jekyll 08312017 0379 edit 3 d807 bf7 96 ad 4 f46 a0 f974 bf561 eccdf cab528c4 b697 44ab a55a85f0007e8bd9 720x480 2cc51087 5b1f 40c5 ad1e 41fe73d3f70f '),(10,'alt',0,1,''),(10,'alt',0,2,''),(10,'extension',0,1,' jpg '),(10,'extension',0,2,' jpg '),(10,'filename',0,1,' dwp drivebrand goldenisles littlestsimons sl2 101721 little st simons sl 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571 jpg '),(10,'filename',0,2,' dwp drivebrand goldenisles littlestsimons sl2 101721 little st simons sl 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571 jpg '),(10,'kind',0,1,' image '),(10,'kind',0,2,' image '),(10,'slug',0,1,''),(10,'slug',0,2,''),(10,'title',0,1,' dwp drivebrand goldenisles littlestsimons sl2 101721 little st simons sl 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571 '),(10,'title',0,2,' dwp drivebrand goldenisles littlestsimons sl2 101721 little st simons sl 1727 720x480 a7016ad7 be5b 4900 9985 20293ab94571 '),(11,'alt',0,1,''),(11,'alt',0,2,''),(11,'extension',0,1,' jpg '),(11,'extension',0,2,' jpg '),(11,'filename',0,1,' dsc 06482 edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a jpg '),(11,'filename',0,2,' dsc 06482 edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a jpg '),(11,'kind',0,1,' image '),(11,'kind',0,2,' image '),(11,'slug',0,1,''),(11,'slug',0,2,''),(11,'title',0,1,' dsc 06482 edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a '),(11,'title',0,2,' dsc 06482 edit 2 720x479 4f933cad 23f3 4357 8cb7 3fa1dc47b36a '),(12,'alt',0,1,''),(12,'alt',0,2,''),(12,'extension',0,1,' jpg '),(12,'extension',0,2,' jpg '),(12,'filename',0,1,' harrington school 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e jpg '),(12,'filename',0,2,' harrington school 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e jpg '),(12,'kind',0,1,' image '),(12,'kind',0,2,' image '),(12,'slug',0,1,''),(12,'slug',0,2,''),(12,'title',0,1,' harrington school 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e '),(12,'title',0,2,' harrington school 1 720x481 93753ce9 adc5 4be4 a131 a5922e29023e '),(13,'alt',0,1,''),(13,'alt',0,2,''),(13,'extension',0,1,' jpg '),(13,'extension',0,2,' jpg '),(13,'filename',0,1,' dsc 1317 expanded inn pool minified jpg '),(13,'filename',0,2,' dsc 1317 expanded inn pool minified jpg '),(13,'kind',0,1,' image '),(13,'kind',0,2,' image '),(13,'slug',0,1,''),(13,'slug',0,2,''),(13,'title',0,1,' dsc 1317 expanded inn pool minified '),(13,'title',0,2,' dsc 1317 expanded inn pool minified '),(14,'alt',0,1,''),(14,'alt',0,2,''),(14,'extension',0,1,' jpg '),(14,'extension',0,2,' jpg '),(14,'filename',0,1,' msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a jpg '),(14,'filename',0,2,' msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a jpg '),(14,'kind',0,1,' image '),(14,'kind',0,2,' image '),(14,'slug',0,1,''),(14,'slug',0,2,''),(14,'title',0,1,' msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a '),(14,'title',0,2,' msp drivebrand goldenisles shrimpboil 060222 5086 720x480 83cd6ab1 fb5e 48c5 9f0a fe70b3bed11a '),(15,'alt',0,1,''),(15,'alt',0,2,''),(15,'extension',0,1,' jpg '),(15,'extension',0,2,' jpg '),(15,'filename',0,1,' dsc 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df jpg '),(15,'filename',0,2,' dsc 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df jpg '),(15,'kind',0,1,' image '),(15,'kind',0,2,' image '),(15,'slug',0,1,''),(15,'slug',0,2,''),(15,'title',0,1,' dsc 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df '),(15,'title',0,2,' dsc 3024 720x479 22b2716e a069 46fa 9062 b4d148c019df '),(18,'alt',0,1,''),(18,'alt',0,2,''),(18,'extension',0,1,' png '),(18,'extension',0,2,' png '),(18,'filename',0,1,' old techdiff png '),(18,'filename',0,2,' old techdiff png '),(18,'kind',0,1,' image '),(18,'kind',0,2,' image '),(18,'slug',0,1,''),(18,'slug',0,2,''),(18,'title',0,1,' old techdiff '),(18,'title',0,2,' old techdiff '),(19,'alt',0,1,''),(19,'alt',0,2,''),(19,'extension',0,1,' jpg '),(19,'extension',0,2,' jpg '),(19,'filename',0,1,' dsc 1317 expanded inn pool jpg '),(19,'filename',0,2,' dsc 1317 expanded inn pool jpg '),(19,'kind',0,1,' image '),(19,'kind',0,2,' image '),(19,'slug',0,1,''),(19,'slug',0,2,''),(19,'title',0,1,' dsc 1317 expanded inn pool '),(19,'title',0,2,' dsc 1317 expanded inn pool '),(20,'alt',0,1,''),(20,'alt',0,2,''),(20,'extension',0,1,' png '),(20,'extension',0,2,' png '),(20,'filename',0,1,' dji 20240204092448 0006 d enhanced nr png '),(20,'filename',0,2,' dji 20240204092448 0006 d enhanced nr png '),(20,'kind',0,1,' image '),(20,'kind',0,2,' image '),(20,'slug',0,1,''),(20,'slug',0,2,''),(20,'title',0,1,' dji 20240204092448 0006 d enhanced nr '),(20,'title',0,2,' dji 20240204092448 0006 d enhanced nr '),(22,'alt',0,1,''),(22,'alt',0,2,''),(22,'extension',0,1,' png '),(22,'extension',0,2,' png '),(22,'filename',0,1,' untitled png '),(22,'filename',0,2,' untitled png '),(22,'kind',0,1,' image '),(22,'kind',0,2,' image '),(22,'slug',0,1,''),(22,'slug',0,2,''),(22,'title',0,1,' untitled '),(22,'title',0,2,' untitled '),(28,'slug',0,1,' first article '),(28,'slug',0,2,' first article '),(28,'title',0,1,' first article '),(28,'title',0,2,' first article '),(33,'slug',0,1,' temp iorifhitpkghvtnygzfwyixlfmsoxlcosxph '),(33,'slug',0,2,' temp iorifhitpkghvtnygzfwyixlfmsoxlcosxph '),(33,'title',0,1,''),(33,'title',0,2,''),(34,'slug',0,1,' test '),(34,'slug',0,2,' test '),(34,'title',0,1,''),(34,'title',0,2,''),(41,'slug',0,1,' temp dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk '),(41,'slug',0,2,' temp dqjxbbjplccfhwgcrihgmgdggnxqxmrptdkk '),(41,'title',0,1,''),(41,'title',0,2,''),(42,'slug',0,1,' temp kvifbcaoumnmobggnxpqvgojuvnpgctojjje '),(42,'slug',0,2,' temp kvifbcaoumnmobggnxpqvgojuvnpgctojjje '),(42,'title',0,1,''),(42,'title',0,2,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gzcvmynwhdphivpzthcffugwwjdzsojmnkqh` (`handle`),
  KEY `idx_fkdxbsqowaczwogwfuigcnwjgpoyijsjetph` (`name`),
  KEY `idx_ztklqmduciymyttvypdosanngvmiaodmkolh` (`structureId`),
  KEY `idx_slhdumgktspbyglffaurzgyfsfsdyjbpmoic` (`dateDeleted`),
  CONSTRAINT `fk_deswlemmvvmrmlztgkmxauleuldwvddssdgi` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-08-26 17:26:34','2024-08-26 17:26:34',NULL,'663ae8bc-bf43-4af2-9213-eb15474f28c0'),(2,NULL,'Blog','blog','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"http://localhost:3000/api/preview?entryUid={canonicalUid}\"}]','2024-08-30 13:28:00','2024-08-30 13:28:00',NULL,'5583777d-063b-4622-92c6-694683de9212');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_aaykupmxjvtpoyikrzvnbrzxflbxrqikzpfn` (`typeId`),
  CONSTRAINT `fk_aaykupmxjvtpoyikrzvnbrzxflbxrqikzpfn` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fssnrudcbgqhgegdyfzegsmawyomoumyzlwl` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1),(2,2,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yyhpcxfksqpputvwwbluimsmlnrwmejvtscz` (`sectionId`,`siteId`),
  KEY `idx_ravexpoqjyhqyihvrdprudcwkjvqjlvhwwaa` (`siteId`),
  CONSTRAINT `fk_awijwhcpqmqrrsxvriwfrknpbrwqotiobyrz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wlidtmomcsvyqrldfaidvgjystwfpbyaqhxz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,2,1,'__home__',NULL,1,'2024-08-26 17:26:34','2024-08-26 17:26:34','c418d800-cf9d-40a4-a940-4e984ef7513e'),(2,1,1,1,'__home__',NULL,1,'2024-08-26 17:26:34','2024-08-26 17:26:34','53704a14-a633-410d-8097-7b372742fcda'),(3,2,2,1,'blog/{slug}',NULL,1,'2024-08-30 13:28:00','2024-08-30 13:28:00','ef5d7bfe-070f-4a98-8a53-83073c5b3e2a'),(4,2,1,1,'blog/{slug}',NULL,1,'2024-08-30 13:28:00','2024-08-30 13:28:00','aeab5477-1f45-467e-8049-224bad0d417a');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_redirects`
--

DROP TABLE IF EXISTS `seo_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_redirects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `type` enum('301','302') NOT NULL,
  `siteId` int DEFAULT NULL,
  `order` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_redirects`
--

LOCK TABLES `seo_redirects` WRITE;
/*!40000 ALTER TABLE `seo_redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_sitemap`
--

DROP TABLE IF EXISTS `seo_sitemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_sitemap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group` enum('sections','categories','productTypes','customUrls') NOT NULL,
  `url` varchar(255) NOT NULL,
  `frequency` enum('always','hourly','daily','weekly','monthly','yearly','never') NOT NULL,
  `priority` float NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_sitemap`
--

LOCK TABLES `seo_sitemap` WRITE;
/*!40000 ALTER TABLE `seo_sitemap` DISABLE KEYS */;
INSERT INTO `seo_sitemap` VALUES (1,'sections','2','weekly',0.5,1,'2024-08-30 18:27:41','2024-09-03 18:39:35','a121d6a3-0f86-4c6f-b235-3eb5a0349165'),(2,'sections','1','weekly',0.5,0,'2024-08-30 18:27:41','2024-09-03 18:39:35','7c6b2701-c0fc-413c-81de-566074effcc1'),(3,'customUrls','','weekly',0.5,1,'2024-09-03 18:39:32','2024-09-03 18:39:35','b9fdbd68-ae96-4437-8f98-a7f03811cac4');
/*!40000 ALTER TABLE `seo_sitemap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bcswmefxedrzqkxdibgwytmkddrkdzbphxpm` (`uid`),
  KEY `idx_nganzvwcyofclkyxrlzmhhzxnztntqletpsg` (`token`),
  KEY `idx_iasriyndriygoptlfowhmexozdhzdjevcgps` (`dateUpdated`),
  KEY `idx_rnyxufvfgzanfydfqczcnbkmuytbacjyxabj` (`userId`),
  CONSTRAINT `fk_wlfkqdsevutxirphomebiecrrsuqwmjyvwzr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'JlI8tuwDfOsllQx3hWOrZjUmyu4J0ii1ZsAqI5qSq8GTOhCOLuZFOFcKJslCqbv3U988G93ooD-mYQE64szM2I8D1xI3cYsjPxb8','2024-08-22 14:07:23','2024-08-22 14:10:09','362e780c-6b7f-41ba-b23a-943be18100e2'),(2,1,'ye4oLLSt6tYjaFJ_JHMxr5OoCWIhHPBtdbMeSWEyHjdlVFlUgZslPm1IkOzFAkVTeLZiNuxIvIgX-mCh655LTLl1D8QdJgJ84qAW','2024-08-26 17:22:43','2024-08-26 17:22:46','5856b3c9-1fdf-4161-95ab-1c5ce6b80b63'),(3,1,'FOUZIIDmwWlXcD_ybBpShqCEz2VwM6rZERTuQDCE5x1fzNbIMIY5zHezXxcTZ3rNHh8NWMmA2T8E3VMDSm2GR4PcX9fYJ5FKDG6G','2024-08-26 17:22:55','2024-08-26 17:48:32','8a64af1d-8501-4e44-a4df-a36251e9bc4c'),(4,1,'gt1lggPv8O0342-0Kakpg5pfbNfptpvNCobmeoIIEGAbOe9ZhulNTeJd6bx4R4yXujG7CUlTDcrNPh8H5WmGNn-xkn1ZJDni23c-','2024-08-26 17:48:32','2024-08-26 17:50:28','91370490-4c55-4152-9b8a-b34e72a4e0c3'),(5,1,'-z7ZW-Pt6nSOV1hG9zbQrYpddcGwis2oKqISuCB9dxSHdMyWdvTRBuwrxdjOnIFNp-gdcSaa1uRm62UlqK2iO9M6JZCXtbFtlrIz','2024-08-26 17:50:28','2024-08-26 18:00:46','f5011219-c5c4-4984-8b93-818f47c456f9'),(7,1,'jiM9Om2P4H8uC0I4yx9fQffo2nnAN8QLiSScW_b3VNUrqoR01Mb1DOJbcQU6iW8WNesO_tAcT3i6NRVKlITiaEVkoKotMD8GRTC7','2024-08-26 20:49:33','2024-08-26 20:52:40','76000ec8-e4b2-49e9-8b73-1280bf05fba4'),(9,1,'zeEnlL5ByUTwMBlWP03RZUdwdNjGF6BZMlX38DOAkqCYRf4DI2mAq_9TpGTYq2Y35d-gRkM_IaSjM1IWjNNNa-fTPIJ_rFhoH-gq','2024-08-27 15:20:25','2024-08-27 15:34:37','720786e2-990d-430a-aa4a-88d62aa5928a'),(10,1,'JtTDzknpqTsS3vlcmX6qRf8edKC65STG5rnQWNgTs7kUvknugxyK9nUs9DRBZMOql_si2jOq0C5ScF4NNnV1eEbpJMNuVnhjXjQN','2024-08-30 13:20:28','2024-08-30 13:30:45','3569cdf7-5ab1-484a-be0c-8cbc3fada4ab'),(11,1,'1zvaZCrpU1UXrTzW6RQ_mgO257ulsE9ljP6tWRBROX7RgQIG8Uj-naqUx-mUInMJO1QsVUQ_mkQv_baRndsBarAiQXTxz3-i2JBB','2024-08-30 13:30:45','2024-08-30 14:14:38','b34e3231-934e-460c-be7e-0d1485998278'),(13,1,'9R8QG_UZqGnXEuxM9Byb-oi6ExpWsOQulual4pmQG6XHmAJD9iM2sJW_HF_43qbuNAmKpKq8lDoyC4fptyZx5mdiktSM39wkT9CH','2024-08-30 16:19:55','2024-08-30 18:10:07','13f57b21-3bc3-4890-8e39-42d515d293e1'),(14,1,'QiqXmO8orUmR0xsXxWigl3oSJUvNeKG2NMtpyaSJSNiLM6dEXG8-6DZNGEsTpP8mHI2QEWShKMQE90jka6u-GoQhSYS8bO3G5SrR','2024-08-30 18:10:07','2024-08-30 19:04:26','da35bf36-ef62-4497-bd37-cce6e1d2a3e0'),(18,1,'nydh25qcv9gQR0SOP2qx4lIaOmNInHm-PnyYaORdNh49_prF0o0rfkqHVWFEeGeS3zNbaYby7iBte88BI4Ue1RpyCUqLdK92rwnD','2024-09-04 16:51:13','2024-09-04 19:45:41','38508cc0-d236-4d82-8de8-38f7a66fe403');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tvqgnrdhaxrmsuincwcfbkldozkizvxglpgd` (`userId`,`message`),
  CONSTRAINT `fk_bfxtcxrgqmwyinnpjwdydegrqvoyldbssyns` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rrmsopzrqfcijecgtbrpmnavcfzocafjerju` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Scaffold','2024-08-22 14:07:09','2024-08-22 14:07:09',NULL,'c077d9b1-5981-44d3-9ec9-77ddb889340c'),(2,'Craft 5caffold','2024-08-22 14:07:09','2024-08-22 14:07:09',NULL,'a033033c-2320-4124-996c-2e6e2c1b2869');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vvrntgwsapaadtgxgugyhwtxrdhmbltthmsx` (`dateDeleted`),
  KEY `idx_glrpdczxrucfjyxjwvnvubmrklpcwkwlvhxe` (`handle`),
  KEY `idx_ihjiigsbrmueebvuosrncyuhrzzhhpabiusb` (`sortOrder`),
  KEY `fk_nsgfpjfnfjfdadmsnlwmzyuutbjpqnnwptia` (`groupId`),
  CONSTRAINT `fk_nsgfpjfnfjfdadmsnlwmzyuutbjpqnnwptia` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,2,0,'1','whocares','whoccares','en-US',1,'$PRIMARY_SITE_URL',1,'2024-08-22 14:07:09','2024-09-03 20:34:48','2024-09-03 20:35:28','ca348b20-8894-41e8-8cbd-4b61bda22ba5'),(2,2,1,'1','Craft 5caffold','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-08-22 14:07:09','2024-09-04 18:24:30',NULL,'2eb36cc0-a60a-4071-a815-ce808da649b2');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_odjtoqspmoqwooohcnurikhfatjjuwiixwmp` (`userId`),
  CONSTRAINT `fk_odjtoqspmoqwooohcnurikhfatjjuwiixwmp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tqizpnyjaltsxdfuoveotznzjizfuadjwbpy` (`structureId`,`elementId`),
  KEY `idx_uikpngeingsschbggtyexfpzmdamphfyjcyv` (`root`),
  KEY `idx_fkluirnfjwbxgojqsfibbyoxqnuzxdevjdou` (`lft`),
  KEY `idx_cqgjgvnotpddtwjsqojqdrcthtbnxjwhzbcv` (`rgt`),
  KEY `idx_bvdsmdjmjplqevsfvjmbppbkzjpnztojnddx` (`level`),
  KEY `idx_wocjavkpvommkgkeyehdjgpsuurxwawelzzv` (`elementId`),
  CONSTRAINT `fk_kznwiybbaqvsmlxdyovwwsrharxbjxdttbpj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ioarfcsgukpzcaaalroyawmbpehskfjhtjjv` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cewmdgvtnfwxnbmyznfijczfbfbyliwupqjz` (`key`,`language`),
  KEY `idx_lfzqjspbgbqvnpfwdojmmhziwtotgqsbazak` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hnyhhwxpvwqpfhpsjxcldavrmldrmdqgdxji` (`name`),
  KEY `idx_ahjingmffegtkakzaaeubibotsdezrzuedxd` (`handle`),
  KEY `idx_wqzlebnjokkskugcoingvogddyuxjaounxir` (`dateDeleted`),
  KEY `fk_mkheuetkhbcozrugkmwazusahanvutaqlrrg` (`fieldLayoutId`),
  CONSTRAINT `fk_mkheuetkhbcozrugkmwazusahanvutaqlrrg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_emngemlpwkbmpfhdbfilaefqneyiuxygaatc` (`groupId`),
  CONSTRAINT `fk_hqxritymrzmcgeiqqmqsitphucprbosqityw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prgyklsqlduvloaomykwpmpnixszswghucts` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_drmupflfocunynzmtgvlrcjuzwfksdvgebxj` (`token`),
  KEY `idx_ticepbpcsnkhyutpmazixjtttrghqwmcopco` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dptfrrmwkumqsjwmyqdthhynwicpkucnozlf` (`handle`),
  KEY `idx_qdbaeokefhyxsychvoarsuyzwqvukyynlaoz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ywqkeeymflvbqnrrwhvtzcsxsoqzvctqylat` (`groupId`,`userId`),
  KEY `idx_qpszjzpkohmjibbdxdibvzvwwosxyosetvwp` (`userId`),
  CONSTRAINT `fk_bxeepgzyecmrppylftdhjymuxsrnhzaisqdz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rzymuhehpfjevoozuhsfcagxpakxualrhqqx` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nbvvizveguhnzdmwdooltsgqsgbikcyzjopp` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lqaeoclhlhvpfrclpkwdlueaqmenphtyygnk` (`permissionId`,`groupId`),
  KEY `idx_ggdqrjkrzqetixpagafgjhjyjvkyaqyjrudf` (`groupId`),
  CONSTRAINT `fk_bxgwdzedltlnkoxweuohswgcvxcgnhviiyuc` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xgxqyyrbdguldvioilvgggiwovpjbzghnqfh` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mribskmwndubgkursxozdcwkjsrywngdasru` (`permissionId`,`userId`),
  KEY `idx_lnuvzgfkktelpwnrnsfyarbvreellkthxvtl` (`userId`),
  CONSTRAINT `fk_siewtrohjwyskepqzsmqwnhjbufhabkotpyd` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tdmoycrdvstbeqdxuzvrawykiquordymttvb` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_uqcvyzdiryhiqscrgrfbjigogvjxxjthbtss` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vexkkarrdptujccctatdfeityerkfkqahsdj` (`active`),
  KEY `idx_elzhsxncwhbrugkoakykuakkylfziksnukov` (`locked`),
  KEY `idx_bktqzpundcqgqldcdtllgulwkjplmrajcxoz` (`pending`),
  KEY `idx_mvclxdtrgxjddcuydurqwlnfpsaxjkwcezir` (`suspended`),
  KEY `idx_mrjhxrzfsipmckmjfygtyidlgzmmioghxllx` (`verificationCode`),
  KEY `idx_ksjumgxvlhifsbtdwbejcxhabsofkghwoumx` (`email`),
  KEY `idx_reedvszpzxtaxnaiowlirhprlitjfsnojpon` (`username`),
  KEY `fk_xmtkbywyoptjsvwizrmolqvpbmqmzjkxhgcu` (`photoId`),
  CONSTRAINT `fk_hymyvtgxguvhmzkkikipcqeqksvhonyadexb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xmtkbywyoptjsvwizrmolqvpbmqmzjkxhgcu` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'daniel@drivebrandstudio.com','$2y$13$oGukOW4qyfRLMz8JI0BALeHFBOBNOzpSfIH8XYGhvH2UAGCGKsSuG','2024-09-04 16:51:13',NULL,NULL,NULL,'2024-09-03 17:02:51',NULL,1,NULL,NULL,NULL,0,'2024-08-22 14:07:10','2024-08-22 14:07:10','2024-09-04 16:51:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cxrkuwdjqwsbkztixhocpqdfqfuouisipfkd` (`name`,`parentId`,`volumeId`),
  KEY `idx_jwxusffkjvwmflgwhlccxlkktckxjmwivzlz` (`parentId`),
  KEY `idx_jmxlefgdzbzchnbgykmjxfembwbdottyoejo` (`volumeId`),
  CONSTRAINT `fk_acbabbifgwixgcuidcgeujzhsxqikgfydnmi` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eqsljwicygxzpdbfohrnddxgkitxlyoxoark` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images',NULL,'2024-08-26 17:29:56','2024-08-26 17:31:05','6b089217-792b-462b-bd45-50c7b74c6af3'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-08-26 17:43:34','2024-08-26 17:43:34','d7b4701a-1087-4d64-a823-b284d99011f7'),(3,2,NULL,'user_1','user_1/','2024-08-26 17:43:34','2024-08-26 17:43:34','1d839d45-3dc2-4955-8368-ec22e1e8bea0');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rsfklhkjuhvbdlojjaensaxanryoamxtlnqq` (`name`),
  KEY `idx_ltisjmgtqhozanapkxzvnrpbpixhkzpofyug` (`handle`),
  KEY `idx_brsmykekftvkhgiauefrvjopomjoqwawtyib` (`fieldLayoutId`),
  KEY `idx_pigrgqylhewgmhcvrtycrfdxzgewkjuguqre` (`dateDeleted`),
  CONSTRAINT `fk_ijioovmykbqfcdxqaetwkqdivxjlkvsqigcf` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,2,'Images','images','public','','public','','site',NULL,'none',NULL,1,'2024-08-26 17:29:56','2024-08-26 17:42:59',NULL,'8618e083-7911-4332-a599-d8c6a8884ed8');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_gpuvsfzucaupxfdxvceszzrjfdqmlgigxgev` (`userId`),
  CONSTRAINT `fk_gpuvsfzucaupxfdxvceszzrjfdqmlgigxgev` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_soygmbwtpmlizntrrooqxvjedixwapautuov` (`userId`),
  CONSTRAINT `fk_chfkdjlniwqnyhpsexbspzyfcisjxdewvtgu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 2, \"section\": \"*\"}',1,'2024-08-22 14:07:23','2024-08-22 14:07:23','ea31781d-c457-44f7-9cd3-320cd8ea219f'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-08-22 14:07:23','2024-08-22 14:07:23','972bc4fe-f0cb-4878-8259-598b6352f512'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-08-22 14:07:23','2024-08-22 14:07:23','d8ba89e1-b02e-4673-864e-2fbf13f112ff'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-08-22 14:07:23','2024-08-22 14:07:23','f74ff92e-ca70-4775-9258-54731354c380');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-09-04 19:46:00
